




#!/usr/bin/env bash
set -euo pipefail

: "${DATA_DIR:?Set DATA_DIR}"
: "${VAE_PATH:?Set VAE_PATH to the local Hugging Face VAE directory}"
IMAGES_SUBDIR="${IMAGES_SUBDIR:-imagenet_256_vae}"
LATENTS_SUBDIR="${LATENTS_SUBDIR:-vae-sd}"

python preprocessing/dataset_tools.py encode \
    --source="${DATA_DIR}/${IMAGES_SUBDIR}" \
    --dest="${DATA_DIR}/${LATENTS_SUBDIR}" \
    --model-url="${VAE_PATH}"
