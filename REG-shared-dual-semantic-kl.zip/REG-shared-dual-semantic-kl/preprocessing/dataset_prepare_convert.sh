




#!/usr/bin/env bash
set -euo pipefail

: "${IMAGENET_DIR:?Set IMAGENET_DIR to the raw ImageNet train directory}"
: "${DATA_DIR:?Set DATA_DIR}"
IMAGES_SUBDIR="${IMAGES_SUBDIR:-imagenet_256_vae}"

python preprocessing/dataset_tools.py convert \
    --source="${IMAGENET_DIR}" \
    --dest="${DATA_DIR}/${IMAGES_SUBDIR}" \
    --resolution=256x256 \
    --transform=center-crop-dhariwal
