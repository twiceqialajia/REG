#!/usr/bin/env bash
set -euo pipefail

NUM_GPUS="${NUM_GPUS:-8}"
: "${DATA_DIR:?Set DATA_DIR}"
: "${ENCODER_PATH:?Set ENCODER_PATH to the local Hugging Face DINOv2 directory}"

MODEL="${MODEL:-SiT-XL/2}"
NUM_REGISTER_TOKENS="${NUM_REGISTER_TOKENS:-4}"
REGISTER_DIM="${REGISTER_DIM:-0}"                 # 0 = full model width; e.g. 256 = low-dimensional register state
REGISTER_MLP_RATIO="${REGISTER_MLP_RATIO:-4.0}"
DUAL_NORM_TYPE="${DUAL_NORM_TYPE:-rmsnorm}"

# Optional layer-only router. The fixed register count is shared by all layers;
# the router learns only one activation weight per layer.
LEARNABLE_ROUTING="${LEARNABLE_ROUTING:-0}"
ROUTER_TEMPERATURE="${ROUTER_TEMPERATURE:-0.10}"
ROUTER_HARD="${ROUTER_HARD:-0}"
ROUTER_HARD_THRESHOLD="${ROUTER_HARD_THRESHOLD:-0.5}"
ROUTER_INIT_GATE="${ROUTER_INIT_GATE:-0.95}"
ROUTER_BUDGET_TYPE="${ROUTER_BUDGET_TYPE:-target}"
ROUTER_BUDGET_TARGET="${ROUTER_BUDGET_TARGET:-0.50}"
BUDGET_COEFF="${BUDGET_COEFF:-0.01}"
ROUTER_BIN_COEFF="${ROUTER_BIN_COEFF:-0.0}"

# DINO-guided CLS->patch semantic KL.  The target is built from clean DINO
# CLS<->patch cosine similarity. Smaller temperature makes the target sharper.
CLS_ATTN_SEMANTIC_KL_COEFF="${CLS_ATTN_SEMANTIC_KL_COEFF:-0.0}"
SEMANTIC_KL_TEMPERATURE="${SEMANTIC_KL_TEMPERATURE:-0.10}"
# tokens_router: lowest VRAM; full: KL directly shapes the full specialized
# register branch. Both use a separate post-main-backward forward, so the main
# graph is never retained for the auxiliary objective.
SEMANTIC_KL_GRAD_SCOPE="${SEMANTIC_KL_GRAD_SCOPE:-tokens_router}"
SHARED_TIMESTEP_PER_BATCH="${SHARED_TIMESTEP_PER_BATCH:-0}"

DIM_TAG="${REGISTER_DIM}"
if [[ "${REGISTER_DIM}" == "0" ]]; then DIM_TAG="full"; fi
ROUTE_TAG="fixed"
if [[ "${LEARNABLE_ROUTING}" == "1" ]]; then ROUTE_TAG="layer-router-b${ROUTER_BUDGET_TARGET}"; fi
SEM_TAG=""
if [[ "${CLS_ATTN_SEMANTIC_KL_COEFF}" != "0" && "${CLS_ATTN_SEMANTIC_KL_COEFF}" != "0.0" ]]; then
    SEM_TAG="-semkl${CLS_ATTN_SEMANTIC_KL_COEFF}-tau${SEMANTIC_KL_TEMPERATURE}"
fi
DEFAULT_EXP_NAME="shared-dual-reg${NUM_REGISTER_TOKENS}-dim${DIM_TAG}-${ROUTE_TAG}${SEM_TAG}"

ROUTER_FLAG="--no-learnable-register-routing"
if [[ "${LEARNABLE_ROUTING}" == "1" ]]; then ROUTER_FLAG="--learnable-register-routing"; fi
HARD_FLAG="--no-router-hard"
if [[ "${ROUTER_HARD}" == "1" ]]; then HARD_FLAG="--router-hard"; fi
SHARED_T_FLAG="--no-shared-timestep-per-batch"
if [[ "${SHARED_TIMESTEP_PER_BATCH}" == "1" ]]; then SHARED_T_FLAG="--shared-timestep-per-batch"; fi

accelerate launch --multi_gpu --num_processes "${NUM_GPUS}" train.py \
    --report-to="wandb" \
    --allow-tf32 \
    --mixed-precision="${MIXED_PRECISION:-fp16}" \
    --seed="${SEED:-0}" \
    --path-type="linear" \
    --prediction="v" \
    --weighting="uniform" \
    --model="${MODEL}" \
    --num-register-tokens="${NUM_REGISTER_TOKENS}" \
    --register-dim="${REGISTER_DIM}" \
    --register-mlp-ratio="${REGISTER_MLP_RATIO}" \
    --dual-norm-type="${DUAL_NORM_TYPE}" \
    "${ROUTER_FLAG}" \
    --router-temperature="${ROUTER_TEMPERATURE}" \
    "${HARD_FLAG}" \
    --router-hard-threshold="${ROUTER_HARD_THRESHOLD}" \
    --router-init-gate="${ROUTER_INIT_GATE}" \
    --router-budget-type="${ROUTER_BUDGET_TYPE}" \
    --router-budget-target="${ROUTER_BUDGET_TARGET}" \
    --budget-coeff="${BUDGET_COEFF}" \
    --router-binarization-coeff="${ROUTER_BIN_COEFF}" \
    --cls-attention-semantic-kl-coeff="${CLS_ATTN_SEMANTIC_KL_COEFF}" \
    --semantic-kl-temperature="${SEMANTIC_KL_TEMPERATURE}" \
    --semantic-kl-grad-scope="${SEMANTIC_KL_GRAD_SCOPE}" \
    "${SHARED_T_FLAG}" \
    --enc-type="dinov2-vit-b" \
    --encoder-path="${ENCODER_PATH}" \
    --proj-coeff="${PROJ_COEFF:-0.5}" \
    --encoder-depth="${ENCODER_DEPTH:-8}" \
    --output-dir="${OUTPUT_DIR:-exps}" \
    --exp-name="${EXP_NAME:-${DEFAULT_EXP_NAME}}" \
    --batch-size="${BATCH_SIZE:-256}" \
    --data-dir="${DATA_DIR}" \
    --images-subdir="${IMAGES_SUBDIR:-imagenet_256_vae}" \
    --latents-subdir="${LATENTS_SUBDIR:-vae-sd}" \
    --cls-coeff="${CLS_COEFF:-0.03}"
