#!/usr/bin/env bash
set -euo pipefail

: "${CKPT:?Set CKPT to a trained checkpoint}"
: "${DATA_DIR:?Set DATA_DIR}"
: "${ENCODER_PATH:?Set ENCODER_PATH}"

python visualize_router.py \
  --ckpt "${CKPT}" \
  --output-dir diagnostics/router

python visualize_attention.py \
  --ckpt "${CKPT}" \
  --data-dir "${DATA_DIR}" \
  --encoder-path "${ENCODER_PATH}" \
  --index "${INDEX:-101}" \
  --timestep "${TIMESTEP:-0.8}" \
  --output-dir diagnostics/attention
