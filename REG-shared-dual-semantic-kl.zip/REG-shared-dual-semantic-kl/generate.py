# Copyright (c) Meta Platforms, Inc. and affiliates.
# Sampling script for shared-register dual-stream SiT checkpoints.

import argparse
import math
import os

import numpy as np
import torch
import torch.distributed as dist
from PIL import Image
from tqdm import tqdm

from models.sit import SiT_models
from samplers import euler_maruyama_sampler
from utils import load_autoencoder, load_legacy_checkpoints


def create_npz_from_sample_folder(sample_dir, num=50_000):
    samples = []
    for i in tqdm(range(num), desc="Building .npz file from samples"):
        sample_pil = Image.open(f"{sample_dir}/{i:06d}.png")
        samples.append(np.asarray(sample_pil).astype(np.uint8))
    samples = np.stack(samples)
    npz_path = f"{sample_dir}.npz"
    np.savez(npz_path, arr_0=samples)
    print(f"Saved {npz_path} [shape={samples.shape}]")
    return npz_path


def checkpoint_args(checkpoint):
    saved = checkpoint.get("args")
    if saved is None:
        return {}
    if isinstance(saved, dict):
        return saved
    return vars(saved)


def load_state(checkpoint, key="ema"):
    if key in checkpoint:
        return checkpoint[key]
    if all(isinstance(value, torch.Tensor) for value in checkpoint.values()):
        return checkpoint
    raise KeyError(f"Checkpoint does not contain '{key}'")


def saved_or_cli(args, saved, name, default=None):
    cli = getattr(args, name, None)
    if cli is not None:
        return cli
    return saved.get(name, default)


def infer_encoder_dim(state, saved):
    if "encoder_embed_dim" in saved:
        return int(saved["encoder_embed_dim"])
    if "cls_projectors2.weight" in state:
        return int(state["cls_projectors2.weight"].shape[1])
    if "projectors.0.4.weight" in state:
        return int(state["projectors.0.4.weight"].shape[0])
    return 768


def main(args):
    torch.backends.cuda.matmul.allow_tf32 = args.tf32
    assert torch.cuda.is_available(), "DDP sampling requires CUDA"
    torch.set_grad_enabled(False)

    dist.init_process_group("nccl")
    rank = dist.get_rank()
    device = rank % torch.cuda.device_count()
    torch.cuda.set_device(device)
    seed = args.global_seed * dist.get_world_size() + rank
    torch.manual_seed(seed)

    checkpoint = torch.load(args.ckpt, map_location="cpu")
    state = load_state(checkpoint, args.checkpoint_key)
    saved = checkpoint_args(checkpoint) if args.arch_from_ckpt else {}

    model_name = saved_or_cli(args, saved, "model", "SiT-XL/2")
    resolution = int(saved_or_cli(args, saved, "resolution", 256))
    num_classes = int(saved_or_cli(args, saved, "num_classes", 1000))
    encoder_depth = int(saved_or_cli(args, saved, "encoder_depth", 8))
    num_register_tokens = int(
        saved_or_cli(args, saved, "num_register_tokens", 4)
    )
    register_dim = int(saved_or_cli(args, saved, "register_dim", 0))
    register_mlp_ratio = float(
        saved_or_cli(args, saved, "register_mlp_ratio", 4.0)
    )
    dual_norm_type = saved_or_cli(
        args, saved, "dual_norm_type", "rmsnorm"
    )
    learnable_register_routing = bool(
        saved_or_cli(args, saved, "learnable_register_routing", False)
    )
    router_temperature = float(
        saved_or_cli(args, saved, "router_temperature", 0.10)
    )
    router_hard = bool(saved_or_cli(args, saved, "router_hard", False))
    router_hard_threshold = float(
        saved_or_cli(args, saved, "router_hard_threshold", 0.5)
    )
    router_init_gate = float(
        saved_or_cli(args, saved, "router_init_gate", 0.95)
    )
    router_budget_type = saved_or_cli(
        args, saved, "router_budget_type", "target"
    )
    router_budget_target = float(
        saved_or_cli(args, saved, "router_budget_target", 0.50)
    )
    qk_norm = bool(saved_or_cli(args, saved, "qk_norm", False))
    encoder_embed_dim = infer_encoder_dim(state, saved)

    # Sampling may optionally binarize a router that was trained softly.
    if args.force_hard_router:
        router_hard = True
        router_hard_threshold = args.force_hard_threshold

    latent_size = resolution // 8
    model = SiT_models[model_name](
        input_size=latent_size,
        num_classes=num_classes,
        use_cfg=True,
        z_dims=[encoder_embed_dim],
        encoder_depth=encoder_depth,
        use_reg=True,
        use_repa=True,
        num_register_tokens=num_register_tokens,
        register_dim=register_dim,
        register_mlp_ratio=register_mlp_ratio,
        dual_norm_type=dual_norm_type,
        learnable_register_routing=learnable_register_routing,
        router_temperature=router_temperature,
        router_hard=router_hard,
        router_hard_threshold=router_hard_threshold,
        router_init_gate=router_init_gate,
        router_budget_type=router_budget_type,
        router_budget_target=router_budget_target,
        fused_attn=args.fused_attn,
        qk_norm=qk_norm,
    ).to(device)

    if args.legacy:
        state = load_legacy_checkpoints(
            state_dict=state, encoder_depth=encoder_depth
        )
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        raise RuntimeError(
            f"Checkpoint/model mismatch. missing={missing}, unexpected={unexpected}"
        )
    model.eval()
    vae = load_autoencoder(args.vae_path, args.vae, device=device)

    model_string_name = model_name.replace("/", "-")
    ckpt_string_name = os.path.basename(args.ckpt).replace(".pt", "")
    folder_name = (
        f"{model_string_name}-{ckpt_string_name}-size-{resolution}-vae-{args.vae}-"
        f"cfg-{args.cfg_scale}-seed-{args.global_seed}-{args.mode}-"
        f"{args.guidance_high}-{args.cls_cfg_scale}"
    )
    sample_folder_dir = f"{args.sample_dir}/{folder_name}"
    if rank == 0:
        os.makedirs(sample_folder_dir, exist_ok=True)
        print(f"Saving PNG samples at {sample_folder_dir}")
        print(
            f"registers={num_register_tokens}, register_dim="
            f"{register_dim or model.hidden_size}, router={learnable_register_routing}, "
            f"hard={router_hard}"
        )
    dist.barrier()

    n = args.per_proc_batch_size
    global_batch_size = n * dist.get_world_size()
    total_samples = int(
        math.ceil(args.num_fid_samples / global_batch_size) * global_batch_size
    )
    samples_needed_this_gpu = total_samples // dist.get_world_size()
    assert samples_needed_this_gpu % n == 0
    iterations = samples_needed_this_gpu // n
    pbar = tqdm(range(iterations)) if rank == 0 else range(iterations)
    total = 0

    for _ in pbar:
        z = torch.randn(n, model.in_channels, latent_size, latent_size, device=device)
        y = torch.randint(0, num_classes, (n,), device=device)
        cls_z = torch.randn(n, encoder_embed_dim, device=device)
        sampling_kwargs = dict(
            model=model,
            latents=z,
            y=y,
            num_steps=args.num_steps,
            heun=args.heun,
            cfg_scale=args.cfg_scale,
            guidance_low=args.guidance_low,
            guidance_high=args.guidance_high,
            path_type=args.path_type,
            cls_latents=cls_z,
            args=args,
        )
        with torch.no_grad():
            if args.mode != "sde":
                raise NotImplementedError("This project currently uses the SDE sampler")
            samples = euler_maruyama_sampler(**sampling_kwargs).float()
            latents_scale = torch.full(
                (1, 4, 1, 1), 0.18215, device=device
            )
            latents_bias = torch.zeros_like(latents_scale)
            samples = vae.decode(
                (samples - latents_bias) / latents_scale
            ).sample
            samples = (samples + 1) / 2
            samples = (
                torch.clamp(255 * samples, 0, 255)
                .permute(0, 2, 3, 1)
                .cpu()
                .to(torch.uint8)
                .numpy()
            )
            for i, sample in enumerate(samples):
                index = i * dist.get_world_size() + rank + total
                Image.fromarray(sample).save(
                    f"{sample_folder_dir}/{index:06d}.png"
                )
        total += global_batch_size

    dist.barrier()
    if rank == 0:
        create_npz_from_sample_folder(sample_folder_dir, args.num_fid_samples)
        print("Done.")
    dist.barrier()
    dist.destroy_process_group()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--global-seed", type=int, default=0)
    parser.add_argument(
        "--tf32", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--ckpt", type=str, required=True)
    parser.add_argument("--checkpoint-key", choices=["ema", "model"], default="ema")
    parser.add_argument("--sample-dir", type=str, default="samples")
    parser.add_argument(
        "--arch-from-ckpt", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--model", type=str, choices=list(SiT_models.keys()), default=None)
    parser.add_argument("--num-classes", type=int, default=None)
    parser.add_argument("--encoder-depth", type=int, default=None)
    parser.add_argument("--resolution", type=int, choices=[256, 512], default=None)
    parser.add_argument("--num-register-tokens", type=int, default=None)
    parser.add_argument("--register-dim", type=int, default=None)
    parser.add_argument("--register-mlp-ratio", type=float, default=None)
    parser.add_argument("--dual-norm-type", choices=["rmsnorm", "layernorm"], default=None)
    parser.add_argument("--learnable-register-routing", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--router-temperature", type=float, default=None)
    parser.add_argument("--router-hard", action=argparse.BooleanOptionalAction, default=None)
    parser.add_argument("--router-hard-threshold", type=float, default=None)
    parser.add_argument("--router-init-gate", type=float, default=None)
    parser.add_argument("--router-budget-type", choices=["target", "l1", "none"], default=None)
    parser.add_argument("--router-budget-target", type=float, default=None)
    parser.add_argument("--force-hard-router", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--force-hard-threshold", type=float, default=0.5)
    parser.add_argument("--fused-attn", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--vae", choices=["ema", "mse"], default=os.environ.get("VAE", "mse"))
    parser.add_argument("--vae-path", type=str, default=os.environ.get("VAE_PATH"))
    parser.add_argument("--per-proc-batch-size", type=int, default=32)
    parser.add_argument("--num-fid-samples", type=int, default=50_000)
    parser.add_argument("--mode", type=str, default="sde")
    parser.add_argument("--cfg-scale", type=float, default=1.5)
    parser.add_argument("--cls-cfg-scale", type=float, default=1.5)
    parser.add_argument("--path-type", choices=["linear", "cosine"], default="linear")
    parser.add_argument("--num-steps", type=int, default=50)
    parser.add_argument("--heun", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--guidance-low", type=float, default=0.0)
    parser.add_argument("--guidance-high", type=float, default=1.0)
    parser.add_argument("--local-rank", default=-1, type=int)
    parser.add_argument("--legacy", action=argparse.BooleanOptionalAction, default=False)
    main(parser.parse_args())
