import math
import numpy as np
import torch
import torch.nn.functional as F


def mean_flat(x):
    return torch.mean(x, dim=list(range(1, len(x.size()))))


def sum_flat(x):
    return torch.sum(x, dim=list(range(1, len(x.size()))))


@torch.no_grad()
def build_dino_semantic_target(
    cls_token,
    patch_tokens,
    target_num_patches,
    temperature=0.10,
):
    """Build a clean-image DINO semantic distribution over image patches.

    The target score for a patch is cosine(DINO_CLS, DINO_patch). If DINO and
    SiT use different patch grids, cosine-similarity logits are resized in 2D
    before softmax. The returned tensor is float32, detached, and sums to one
    over patches.
    """
    if temperature <= 0:
        raise ValueError("semantic KL temperature must be > 0")
    if cls_token.ndim != 2 or patch_tokens.ndim != 3:
        raise ValueError(
            "Expected cls_token [B,D] and patch_tokens [B,N,D], got "
            f"{tuple(cls_token.shape)} and {tuple(patch_tokens.shape)}"
        )
    if cls_token.shape[0] != patch_tokens.shape[0]:
        raise ValueError("DINO CLS/patch batch-size mismatch")
    if cls_token.shape[-1] != patch_tokens.shape[-1]:
        raise ValueError("DINO CLS/patch embedding-dimension mismatch")

    cls_norm = F.normalize(cls_token.float(), dim=-1)
    patch_norm = F.normalize(patch_tokens.float(), dim=-1)
    semantic_logits = torch.einsum("bd,bnd->bn", cls_norm, patch_norm)

    source_n = semantic_logits.shape[1]
    target_n = int(target_num_patches)
    if source_n != target_n:
        source_grid = int(round(math.sqrt(source_n)))
        target_grid = int(round(math.sqrt(target_n)))
        if source_grid * source_grid != source_n:
            raise ValueError(
                f"DINO patch count {source_n} is not a square grid; cannot resize"
            )
        if target_grid * target_grid != target_n:
            raise ValueError(
                f"SiT patch count {target_n} is not a square grid; cannot resize"
            )
        semantic_logits = F.interpolate(
            semantic_logits.view(-1, 1, source_grid, source_grid),
            size=(target_grid, target_grid),
            mode="bilinear",
            align_corners=False,
        ).flatten(1)

    target = F.softmax(semantic_logits / float(temperature), dim=-1)
    return target.detach()


class SILoss:
    def __init__(
        self,
        prediction="v",
        path_type="linear",
        weighting="uniform",
        encoders=[],
        accelerator=None,
        latents_scale=None,
        latents_bias=None,
        use_reg=True,
        use_repa=True,
        shared_timestep_per_batch=False,
    ):
        self.prediction = prediction
        self.weighting = weighting
        self.path_type = path_type
        self.encoders = encoders
        self.accelerator = accelerator
        self.latents_scale = latents_scale
        self.latents_bias = latents_bias
        self.use_reg = bool(use_reg)
        self.use_repa = bool(use_repa)
        self.shared_timestep_per_batch = bool(shared_timestep_per_batch)

    def interpolant(self, t):
        if self.path_type == "linear":
            alpha_t = 1 - t
            sigma_t = t
            d_alpha_t = -1
            d_sigma_t = 1
        elif self.path_type == "cosine":
            alpha_t = torch.cos(t * np.pi / 2)
            sigma_t = torch.sin(t * np.pi / 2)
            d_alpha_t = -np.pi / 2 * torch.sin(t * np.pi / 2)
            d_sigma_t = np.pi / 2 * torch.cos(t * np.pi / 2)
        else:
            raise NotImplementedError()
        return alpha_t, sigma_t, d_alpha_t, d_sigma_t

    def sample_time(self, batch_size, device, dtype):
        sample_batch = 1 if self.shared_timestep_per_batch else batch_size
        if self.weighting == "uniform":
            time_input = torch.rand((sample_batch, 1, 1, 1), device=device)
        elif self.weighting == "lognormal":
            rnd_normal = torch.randn((sample_batch, 1, 1, 1), device=device)
            sigma = rnd_normal.exp()
            if self.path_type == "linear":
                time_input = sigma / (1 + sigma)
            elif self.path_type == "cosine":
                time_input = 2 / np.pi * torch.atan(sigma)
            else:
                raise NotImplementedError()
        else:
            raise ValueError(f"Unknown timestep weighting: {self.weighting}")
        if self.shared_timestep_per_batch:
            time_input = time_input.expand(batch_size, -1, -1, -1).clone()
        return time_input.to(device=device, dtype=dtype)

    def _build_noisy_inputs(
        self,
        images,
        cls_token,
        time_input=None,
        noises=None,
        noises_cls=None,
    ):
        if time_input is None:
            time_input = self.sample_time(
                images.shape[0], images.device, images.dtype
            )
        time_input = time_input.to(device=images.device, dtype=images.dtype)
        if noises is None:
            noises = torch.randn_like(images)

        alpha_t, sigma_t, d_alpha_t, d_sigma_t = self.interpolant(time_input)
        model_input = alpha_t * images + sigma_t * noises

        cls_input = None
        if self.use_reg:
            if cls_token is None:
                raise ValueError("REG loss requires a clean class-token target")
            if noises_cls is None:
                noises_cls = torch.randn_like(cls_token)
            cls_alpha = alpha_t.flatten(1)[:, :1]
            cls_sigma = sigma_t.flatten(1)[:, :1]
            cls_input = cls_alpha * cls_token + cls_sigma * noises_cls

        return (
            model_input,
            cls_input,
            time_input,
            noises,
            noises_cls,
            alpha_t,
            sigma_t,
            d_alpha_t,
            d_sigma_t,
        )

    def __call__(
        self,
        model,
        images,
        model_kwargs=None,
        zs=None,
        cls_token=None,
        time_input=None,
        noises=None,
        noises_cls=None,
    ):
        if model_kwargs is None:
            model_kwargs = {}

        (
            model_input,
            cls_input,
            time_input,
            noises,
            noises_cls,
            alpha_t,
            sigma_t,
            d_alpha_t,
            d_sigma_t,
        ) = self._build_noisy_inputs(
            images,
            cls_token,
            time_input=time_input,
            noises=noises,
            noises_cls=noises_cls,
        )

        if self.prediction == "v":
            model_target = d_alpha_t * images + d_sigma_t * noises
            if self.use_reg:
                cls_d_alpha = (
                    d_alpha_t.flatten(1)[:, :1]
                    if isinstance(d_alpha_t, torch.Tensor)
                    else d_alpha_t
                )
                cls_d_sigma = (
                    d_sigma_t.flatten(1)[:, :1]
                    if isinstance(d_sigma_t, torch.Tensor)
                    else d_sigma_t
                )
                cls_target = cls_d_alpha * cls_token + cls_d_sigma * noises_cls
            else:
                cls_target = None
        else:
            raise NotImplementedError()

        model_result = model(
            model_input,
            time_input.flatten(),
            **model_kwargs,
            cls_token=cls_input,
            return_router_aux=True,
        )
        model_output, zs_tilde, cls_output, router_aux = model_result

        denoising_loss = mean_flat((model_output - model_target) ** 2)
        if self.use_reg:
            denoising_loss_cls = mean_flat((cls_output - cls_target) ** 2)
        else:
            denoising_loss_cls = torch.zeros_like(denoising_loss)

        if self.use_repa:
            if zs is None or zs_tilde is None:
                raise ValueError("REPA loss requires target and projected representations")
            if len(zs) != len(zs_tilde):
                raise ValueError("REPA encoder/projector count mismatch")
            losses = []
            for z, z_tilde in zip(zs, zs_tilde):
                if z.shape != z_tilde.shape:
                    raise ValueError(
                        f"REPA token shape mismatch: target={tuple(z.shape)}, "
                        f"prediction={tuple(z_tilde.shape)}"
                    )
                z = F.normalize(z, dim=-1)
                z_tilde = F.normalize(z_tilde, dim=-1)
                losses.append(-(z * z_tilde).sum(dim=-1).mean(dim=1))
            proj_loss = torch.stack(losses).mean(dim=0)
        else:
            proj_loss = torch.zeros_like(denoising_loss)

        budget_loss = router_aux["budget_loss"]
        router_entropy = router_aux["router_entropy"]
        router_stats = {
            "mean_usage": router_aux["mean_usage"],
            "expected_active_registers": router_aux["expected_active_registers"],
            "expected_active_layers": router_aux["expected_active_layers"],
            "router_entropy": router_entropy.detach(),
        }
        return (
            denoising_loss,
            proj_loss,
            time_input,
            noises,
            noises_cls,
            denoising_loss_cls,
            budget_loss,
            router_entropy,
            router_stats,
        )

    def semantic_kl_loss(
        self,
        model,
        images,
        semantic_target,
        model_kwargs=None,
        cls_token=None,
        time_input=None,
        noises=None,
        noises_cls=None,
    ):
        """Re-run only the SiT block stack and compute delayed DINO semantic KL.

        This is intentionally called *after* the main-loss backward in train.py.
        The main graph is therefore already freed before the auxiliary graph is
        created, avoiding the large VRAM peak caused by retain_graph=True.
        """
        if model_kwargs is None:
            model_kwargs = {}
        if semantic_target is None:
            raise ValueError("semantic_target is required")

        (
            model_input,
            cls_input,
            time_input,
            noises,
            noises_cls,
            _,
            _,
            _,
            _,
        ) = self._build_noisy_inputs(
            images,
            cls_token,
            time_input=time_input,
            noises=noises,
            noises_cls=noises_cls,
        )

        router_aux = model(
            model_input,
            time_input.flatten(),
            **model_kwargs,
            cls_token=cls_input,
            return_router_aux=True,
            semantic_target=semantic_target,
            return_cls_patch_semantic_kl=True,
            semantic_kl_only=True,
        )
        kl_by_layer = router_aux["cls_patch_semantic_kl_by_layer"]
        if kl_by_layer is None or kl_by_layer.ndim != 2:
            raise ValueError("Missing CLS->patch semantic KL diagnostics")
        if kl_by_layer.shape[1] < 2:
            raise ValueError("Delayed semantic KL supervision requires depth >= 2")

        # Layer 0 is intentionally excluded: its CLS query and patch keys are
        # formed before any register has had a chance to alter the main stream.
        semantic_kl = kl_by_layer[:, 1:].mean()
        stats = {
            "semantic_kl": semantic_kl.detach(),
            "semantic_kl_by_layer": kl_by_layer.detach().mean(dim=0),
        }
        return semantic_kl, stats
