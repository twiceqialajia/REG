"""Smoke tests for dual-stream shared registers, low-dimensional state,
layer-only routing and DINO-guided CLS->patch semantic KL supervision.
"""

import torch

from loss import SILoss, build_dino_semantic_target
from models.sit import LearnableLayerRouter, SiT
from samplers import euler_maruyama_sampler


def tiny_model(register_dim=16, routed=True, hard=False):
    model = SiT(
        input_size=8,
        patch_size=2,
        hidden_size=64,
        decoder_hidden_size=64,
        depth=4,
        num_heads=4,
        z_dims=[32],
        projector_dim=64,
        encoder_depth=1,
        num_classes=10,
        class_dropout_prob=0.0,
        use_reg=True,
        use_repa=True,
        num_register_tokens=4,
        register_dim=register_dim,
        dual_norm_type="rmsnorm",
        learnable_register_routing=routed,
        router_temperature=0.1,
        router_hard=hard,
        router_init_gate=0.9,
        router_budget_type="target",
        router_budget_target=0.5,
        fused_attn=False,
        qk_norm=False,
    )
    # Make the fixture resemble a trained model rather than adaLN-zero init.
    for block in model.blocks:
        torch.nn.init.normal_(block.patch_adaLN[-1].weight, std=0.02)
        torch.nn.init.normal_(block.patch_adaLN[-1].bias, std=0.02)
        torch.nn.init.normal_(block.register_adaLN[-1].weight, std=0.02)
        torch.nn.init.normal_(block.register_adaLN[-1].bias, std=0.02)
    torch.nn.init.normal_(model.final_layer.linear.weight, std=0.02)
    torch.nn.init.normal_(model.final_layer.linear_cls.weight, std=0.02)
    return model


def inputs(batch=2):
    return (
        torch.randn(batch, 4, 8, 8),
        torch.tensor([1, 2][:batch]),
        torch.randn(batch, 32),
        [torch.randn(batch, 17, 32)],
    )


def semantic_target(batch=2, patches=16):
    x = torch.randn(batch, patches)
    return x.softmax(dim=-1)


def test_low_dim_dual_stream_shapes_and_gradients():
    model = tiny_model(register_dim=16, routed=False)
    images, labels, cls, _ = inputs()
    out, _, cls_out = model(images, torch.tensor([0.2, 0.8]), labels, cls_token=cls)
    assert out.shape == images.shape
    assert cls_out.shape == cls.shape
    assert model.register_tokens.shape[-1] == 16
    assert model.blocks[0].register_to_attention.in_features == 16
    assert model.blocks[0].register_to_attention.out_features == 64
    (out.square().mean() + cls_out.square().mean()).backward()
    assert model.register_tokens.grad is not None
    assert model.register_tokens.grad.abs().sum() > 0
    assert model.blocks[0].register_mlp.fc1.weight.grad is not None
    assert model.blocks[0].patch_mlp.fc1.weight.grad is not None


def test_patch_and_register_modules_are_separate_but_attention_is_single():
    model = tiny_model(register_dim=64, routed=False)
    block = model.blocks[0]
    assert block.patch_norm1 is not block.register_norm1
    assert block.patch_norm2 is not block.register_norm2
    assert block.patch_mlp is not block.register_mlp
    assert block.patch_adaLN is not block.register_adaLN
    assert hasattr(block, "attn")
    assert not hasattr(block, "register_attn")


def test_layer_router_is_timestep_independent_and_shared_across_registers():
    router = LearnableLayerRouter(
        depth=3,
        num_register_tokens=4,
        temperature=0.1,
        init_gate=0.7,
        budget_type="target",
        budget_target=0.5,
    )
    low_g, _, low = router(torch.tensor([0.1]), batch_size=1)
    high_g, _, high = router(torch.tensor([0.9]), batch_size=1)
    assert torch.allclose(low_g, high_g)
    assert torch.allclose(low["soft_layer_gates"], high["soft_layer_gates"])
    assert torch.allclose(low_g[:, :, :1].expand_as(low_g), low_g)


def test_budget_loss_has_gradient_to_layer_logits():
    router = LearnableLayerRouter(
        depth=3,
        num_register_tokens=4,
        temperature=0.1,
        init_gate=0.9,
        budget_type="target",
        budget_target=0.25,
    )
    _, _, aux = router(torch.tensor([0.2, 0.8]), batch_size=2)
    aux["budget_loss"].backward()
    assert router.layer_logits.grad is not None
    assert router.layer_logits.grad.abs().sum() > 0


def test_dino_semantic_target_is_probability_and_resizes_grid():
    cls = torch.randn(2, 32)
    patches = torch.randn(2, 16, 32)
    target = build_dino_semantic_target(
        cls, patches, target_num_patches=4, temperature=0.1
    )
    assert target.shape == (2, 4)
    assert not target.requires_grad
    assert torch.allclose(target.sum(dim=-1), torch.ones(2), atol=1e-5)
    assert (target >= 0).all()


def test_model_returns_semantic_kl_per_layer_without_full_attention_matrix():
    model = tiny_model(register_dim=16, routed=True)
    images, labels, cls, _ = inputs(batch=1)
    target = semantic_target(batch=1, patches=16)
    aux = model(
        images,
        torch.tensor([0.8]),
        labels,
        cls_token=cls,
        semantic_target=target,
        return_router_aux=True,
        return_cls_patch_semantic_kl=True,
        semantic_kl_only=True,
    )
    kl = aux["cls_patch_semantic_kl_by_layer"]
    assert kl.shape == (1, 4)
    assert torch.isfinite(kl).all()
    assert (kl >= -1e-5).all()


def test_siloss_separate_semantic_kl_uses_one_layer_delay():
    model = tiny_model(register_dim=16, routed=True)
    images, labels, cls, targets = inputs()
    loss_fn = SILoss(use_reg=True, use_repa=True)
    main = loss_fn(model, images, {"y": labels}, zs=targets, cls_token=cls)
    assert len(main) == 9
    _, _, time_input, noises, noises_cls, _, _, _, _ = main
    sem, stats = loss_fn.semantic_kl_loss(
        model,
        images,
        semantic_target=semantic_target(batch=2, patches=16),
        model_kwargs={"y": labels},
        cls_token=cls,
        time_input=time_input,
        noises=noises,
        noises_cls=noises_cls,
    )
    assert sem.requires_grad
    assert float(sem.detach()) >= -1e-5
    assert stats["semantic_kl_by_layer"].shape == (4,)


def test_attention_layout_and_layer_router_info():
    model = tiny_model(register_dim=16, routed=True).eval()
    images, labels, cls, _ = inputs(batch=1)
    result = model(
        images,
        torch.tensor([0.8]),
        labels,
        cls_token=cls,
        return_attention=True,
        attention_layers=[0],
    )
    info = result[-1]
    assert info["register_range"] == (1, 5)
    assert info["patch_start"] == 5
    assert info["register_dim"] == 16
    assert info["router_soft_gates"].shape == (1, 4, 4)
    assert info["router_layer_gates"].shape == (4,)
    assert info["weights"][0].shape[-1] == 21


def test_sampler_still_uses_three_output_model_api():
    model = tiny_model(register_dim=16, routed=True).eval()
    samples = euler_maruyama_sampler(
        model=model,
        latents=torch.randn(2, 4, 8, 8),
        y=torch.tensor([1, 2]),
        num_steps=3,
        cfg_scale=1.0,
        path_type="linear",
        cls_latents=torch.randn(2, 32),
    )
    assert samples.shape == (2, 4, 8, 8)
    assert torch.isfinite(samples).all()


def test_semantic_kl_aux_grad_selection_updates_registers_not_patch_backbone():
    from register_aux import (
        add_register_aux_grads,
        compute_register_only_aux_grads,
        get_register_aux_parameters,
    )

    class DummyAccelerator:
        gradient_accumulation_steps = 1
        num_processes = 1
        scaler = None

        @staticmethod
        def unwrap_model(model):
            return model

    accelerator = DummyAccelerator()
    model = tiny_model(register_dim=16, routed=True)
    images, labels, cls, _ = inputs()
    aux = model(
        images,
        torch.tensor([0.3, 0.8]),
        labels,
        cls_token=cls,
        semantic_target=semantic_target(batch=2, patches=16),
        return_router_aux=True,
        return_cls_patch_semantic_kl=True,
        semantic_kl_only=True,
    )
    semantic_kl = aux["cls_patch_semantic_kl_by_layer"][:, 1:].mean()
    named = get_register_aux_parameters(model, accelerator, scope="full")
    aux_grads = compute_register_only_aux_grads(semantic_kl, named, accelerator)

    model.zero_grad(set_to_none=True)
    add_register_aux_grads(named, aux_grads, accelerator)

    assert model.register_tokens.grad is not None
    assert model.register_tokens.grad.abs().sum() > 0
    assert model.register_router.layer_logits.grad is not None
    assert model.blocks[0].register_mlp.fc1.weight.grad is not None
    assert model.blocks[0].patch_mlp.fc1.weight.grad is None
    assert model.blocks[0].attn.qkv.weight.grad is None
    assert model.cls_projectors2.weight.grad is None
