#!/usr/bin/env bash
set -euo pipefail

: "${CKPT:?Set CKPT}"
: "${VAE_PATH:?Set VAE_PATH}"
NUM_GPUS="${NUM_GPUS:-8}"

SAMPLE_DIR="${SAMPLE_DIR:-samples_shared_dual}"

torchrun --nproc_per_node="${NUM_GPUS}" generate.py \
  --ckpt "${CKPT}" \
  --vae-path "${VAE_PATH}" \
  --vae "${VAE:-mse}" \
  --mode sde \
  --num-steps "${NUM_STEPS:-250}" \
  --cfg-scale "${CFG_SCALE:-1}" \
  --cls-cfg-scale "${CLS_CFG_SCALE:-1}" \
  --guidance-high "${GUIDANCE_HIGH:-0.85}" \
  --per-proc-batch-size "${PER_PROC_BATCH_SIZE:-64}" \
  --num-fid-samples "${NUM_FID_SAMPLES:-50000}" \
  --sample-dir "${SAMPLE_DIR}"
