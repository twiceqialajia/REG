import os
import random
from pathlib import Path
from PIL import Image

def concat_images_horizontally(left_dir, right_dir, output_dir, N, shuffle=False, seed=None):
    """
    从 left_dir 和 right_dir 中选取相同名称的 N 张图像，
    将它们横向拼接（左图来自 left_dir，右图来自 right_dir），
    并保存到 output_dir。

    Args:
        left_dir (str): 左侧图像目录
        right_dir (str): 右侧图像目录
        output_dir (str): 输出目录
        N (int): 要拼接的图像对数量
        shuffle (bool): 是否随机选取；若 False 则按文件名排序后取前 N 个
        seed (int): 随机种子（shuffle=True 时有效）
    """
    left_path = Path(left_dir)
    right_path = Path(right_dir)
    out_path = Path(output_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    # 获取两个目录中共同存在的图像文件名（支持常见格式）
    valid_exts = {'.png', '.jpg', '.jpeg', '.bmp', '.webp', '.tif', '.tiff'}
    left_files = {p.name for p in left_path.iterdir() if p.suffix.lower() in valid_exts}
    right_files = {p.name for p in right_path.iterdir() if p.suffix.lower() in valid_exts}
    common_files = sorted(left_files & right_files)

    if len(common_files) < N:
        raise ValueError(f"共同图像数量不足：需要 {N}，但只有 {len(common_files)} 张")

    if shuffle:
        if seed is not None:
            random.seed(seed)
        selected = random.sample(common_files, N)
    else:
        selected = common_files[:N]

    for idx, name in enumerate(selected, 1):
        img_left = Image.open(left_path / name).convert('RGB')
        img_right = Image.open(right_path / name).convert('RGB')

        # 如果两张图高度不同，可以选择将较高的缩放到较低的相同高度，或简单使用最大高度并填充
        # 这里示例：统一高度为左右图高度的较大值，宽度为两图宽度之和，另一侧用黑色填充
        max_height = max(img_left.height, img_right.height)
        if img_left.height != max_height:
            new_width = int(img_left.width * max_height / img_left.height)
            img_left = img_left.resize((new_width, max_height))
        if img_right.height != max_height:
            new_width = int(img_right.width * max_height / img_right.height)
            img_right = img_right.resize((new_width, max_height))

        concat_width = img_left.width + img_right.width
        concat_img = Image.new('RGB', (concat_width, max_height), (0, 0, 0))
        concat_img.paste(img_left, (0, 0))
        concat_img.paste(img_right, (img_left.width, 0))

        # 保存拼接图像，文件名使用原名称（可加前缀避免覆盖）
        out_file = out_path / f"{idx:04d}_{name}"
        concat_img.save(out_file)
        print(f"[{idx}/{N}] 已保存: {out_file}")

    print("完成！")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="横向拼接两个目录中的对应图像")
    parser.add_argument("--left_dir", type=str, required=True, help="左侧图像目录")
    parser.add_argument("--right_dir", type=str, required=True, help="右侧图像目录")
    parser.add_argument("--output_dir", type=str, required=True, help="输出目录")
    parser.add_argument("--N", type=int, required=True, help="拼接的图像对数量")
    parser.add_argument("--shuffle", action="store_true", help="是否随机选取 N 张")
    parser.add_argument("--seed", type=int, default=42, help="随机种子（仅当 shuffle 时有效）")
    args = parser.parse_args()

    concat_images_horizontally(
        left_dir=args.left_dir,
        right_dir=args.right_dir,
        output_dir=args.output_dir,
        N=args.N,
        shuffle=args.shuffle,
        seed=args.seed
    )
