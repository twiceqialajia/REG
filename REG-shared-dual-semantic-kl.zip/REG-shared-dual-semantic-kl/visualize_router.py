"""Visualize the learned timestep-independent layer router."""

import argparse
import csv
import os

import numpy as np
import torch


def checkpoint_args(checkpoint):
    saved = checkpoint.get("args", {})
    if hasattr(saved, "__dict__"):
        return vars(saved)
    return dict(saved)


def main(args):
    import matplotlib.pyplot as plt

    os.makedirs(args.output_dir, exist_ok=True)
    checkpoint = torch.load(args.ckpt, map_location="cpu")
    state = checkpoint[args.checkpoint_key]
    saved = checkpoint_args(checkpoint)

    key = "register_router.layer_logits"
    if key not in state:
        raise RuntimeError(
            "Checkpoint has no layer-only register router. Train with "
            "--learnable-register-routing."
        )

    logits = state[key].float().cpu()
    temperature = float(saved.get("router_temperature", 0.10))
    hard_threshold = float(saved.get("router_hard_threshold", 0.5))
    num_registers = int(saved.get("num_register_tokens", 4))
    gates = torch.sigmoid(logits / temperature).numpy()
    hard = gates >= hard_threshold

    csv_path = os.path.join(args.output_dir, "router_layer_gates.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["layer", "gate", "hard_active", "expected_registers"])
        for layer, gate in enumerate(gates):
            writer.writerow(
                [layer, float(gate), int(hard[layer]), float(gate * num_registers)]
            )

    np.save(os.path.join(args.output_dir, "router_layer_gates.npy"), gates)

    plt.figure(figsize=(8, 4))
    plt.plot(np.arange(len(gates)), gates, marker="o", linewidth=1.5)
    plt.axhline(hard_threshold, linestyle="--", linewidth=1.0, label="hard threshold")
    plt.ylim(0, 1)
    plt.xlabel("Transformer layer")
    plt.ylabel("Register activation weight")
    plt.title("Learned layer-only register routing")
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, "router_layer_gates.png"), dpi=220)
    plt.close()

    print(f"saved {csv_path}")
    print(f"mean layer usage={gates.mean():.4f}")
    print(f"expected active layers={gates.sum():.2f}/{len(gates)}")
    print(f"hard active layers={hard.sum()}/{len(gates)}")
    print(f"fixed register count={num_registers}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--checkpoint-key", choices=["ema", "model"], default="ema")
    parser.add_argument("--output-dir", default="router_diagnostics")
    main(parser.parse_args())
