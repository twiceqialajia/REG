# REG: Shared Dual-Stream Registers + DINO Semantic KL

这一分支完全以 **shared registers** 为起点，不再包含实验 H 的 dynamic/timestep register，也彻底移除了 CLS attention entropy loss。

当前方法由三部分组成：

1. **Dual-stream shared registers**：register 与 patch/CLS 使用独立 RMSNorm、AdaLN、MLP，但共用同一套 self-attention；
2. **可选 layer-only router**：每层只学习一个 register activation weight，不依赖 timestep，也不学习 register 数量；
3. **DINO-guided CLS→Patch Semantic KL**：用 clean DINO CLS 与 patch token 的语义相似度构造空间 target，引导 DiT CLS→patch attention 聚焦到正确语义区域。

---

## 1. Dual-stream register

每个 block 内：

- Patch/CLS stream：自己的 RMSNorm / AdaLN / MLP；
- Register stream：自己的 RMSNorm / AdaLN / MLP；
- Attention：两条 stream 共用 QKV / self-attention / output projection。

Register 仍支持低维 native state：

```bash
REGISTER_DIM=256
```

进入 attention 前映射到主 hidden width，attention 后再映射回 register native width。

`REGISTER_DIM=0` 表示 full-dimensional register。

---

## 2. 可选 layer-only router

开启：

```bash
LEARNABLE_ROUTING=1
```

每层一个标量 gate：

\[
g_l=\sigma(s_l/T).
\]

固定 K 个 shared registers 在同一层共用这个 gate。关闭 router 时所有层始终使用 registers。

Budget loss：

\[
L_{budget}=\left(\frac1L\sum_l g_l-\rho\right)^2.
\]

---

## 3. DINO Semantic KL

### DINO target

对 clean image 的 DINO features：

\[
z_{CLS}, z_1,\ldots,z_N,
\]

先计算：

\[
s_i=\cos(z_{CLS},z_i),
\]

再使用 temperature 构造 semantic target：

\[
q_i=\operatorname{softmax}(s_i/\tau).
\]

- DINO 决定 **CLS 应该关注哪里**；
- `SEMANTIC_KL_TEMPERATURE` 决定 target 有多尖锐。

如果 DINO patch grid 与 SiT patch grid 不同，会先在二维空间对 cosine logits 做 bilinear resize，再 softmax。

### DiT prediction

每层取：

\[
A_{CLS\rightarrow Patch}
\]

只在 patch keys 内归一化，并先对 attention heads 的 patch distribution 求平均，得到：

\[
p_l.
\]

优化：

\[
L_{sem}=D_{KL}(q\Vert p_l).
\]

第 0 层不参与 semantic KL，因为第 0 层 CLS query / patch keys 尚未受到任何前序 register block 的影响。实际 loss 使用：

\[
L_{sem}=\frac1{L-1}\sum_{l=1}^{L-1}D_{KL}(q\Vert p_l).
\]

这保持了 one-layer-delayed register supervision 的逻辑。

---

## 4. 显存友好的两阶段 backward

旧 entropy 版本会在主 graph 还存在时调用：

```python
torch.autograd.grad(..., retain_graph=True)
```

这在 XL 上会产生很高峰值显存。

Semantic-KL 版本改为：

```text
main forward
    ↓
main loss backward
    ↓
主 graph 释放
    ↓
semantic-KL-only forward
    ↓
只对 register 参数求 auxiliary gradients
    ↓
merge gradient → clip → optimizer.step
```

所以 KL 不再需要 `retain_graph=True`。

主训练目标仍正常更新整个网络；semantic KL 的直接梯度只作用于 register branch / 可选 router，不直接写入 patch/CLS backbone。

### Gradient scope

最低显存：

```bash
SEMANTIC_KL_GRAD_SCOPE=tokens_router
```

KL 直接更新：

- `register_tokens`
- `register_router`（如果启用）

更完整的 register-only supervision：

```bash
SEMANTIC_KL_GRAD_SCOPE=full
```

额外更新：

- register RMSNorm
- register AdaLN
- register MLP
- low-dim projections

`full` 仍然比旧 entropy 实现更省峰值显存，因为 auxiliary graph 是在 main backward 后重新建立的；但它会额外保存完整 register branch 的 auxiliary gradient tensors，因此 XL 显存仍会高于 `tokens_router`。

---

## 推荐实验

### A. 当前最好结构 + Semantic KL，不开 router

如果你现在最好的是 `shared-dual-reg4-dimfull-fixed`：

```bash
DATA_DIR=/path/to/data \
ENCODER_PATH=/path/to/dinov2-base \
MODEL=SiT-XL/2 \
NUM_REGISTER_TOKENS=4 \
REGISTER_DIM=0 \
LEARNABLE_ROUTING=0 \
CLS_ATTN_SEMANTIC_KL_COEFF=0.005 \
SEMANTIC_KL_TEMPERATURE=0.10 \
SEMANTIC_KL_GRAD_SCOPE=tokens_router \
bash train.sh
```

建议第一轮扫：

```text
CLS_ATTN_SEMANTIC_KL_COEFF = 0, 0.001, 0.002, 0.005, 0.01
SEMANTIC_KL_TEMPERATURE    = 0.05, 0.10, 0.20
```

建议先固定 `tau=0.1` 调 coefficient，再调 tau。

### B. 开 layer router

```bash
LEARNABLE_ROUTING=1 \
ROUTER_INIT_GATE=0.95 \
ROUTER_BUDGET_TARGET=0.5 \
BUDGET_COEFF=0.01 \
CLS_ATTN_SEMANTIC_KL_COEFF=0.005 \
SEMANTIC_KL_TEMPERATURE=0.10 \
bash train.sh
```

---

## 训练日志

新增：

- `cls_attn_semantic_kl`：未乘系数的 DINO semantic KL；
- `cls_attn_semantic_kl_loss`：乘 coefficient 后的辅助 loss；
- `router_usage`；
- `router_active_layers`；
- `router_active_regs`；
- `budget_loss`；
- `router_entropy`。

---

## Attention / DINO target 可视化

```bash
python visualize_attention.py \
  --ckpt exps/xxx/checkpoints/0400000.pt \
  --data-dir /path/to/data \
  --encoder-path /path/to/dinov2-base \
  --index 100 \
  --timestep 0.8 \
  --layers 0 4 8 12 16 20 24 27 \
  --output-dir attention_diag
```

除了原有的逐层 CLS→patch heatmap、overlay、全层平均图，还会输出：

- `dino_semantic_target.npy`
- `dino_semantic_target.png`
- `dino_semantic_target_overlay.png`

`attention_summary.csv` 也会包含每层：

```text
dino_semantic_kl
```

方便直接检查训练后的 CLS attention 是否向 DINO target 靠近。

---

## 关键参数

| 参数 | 含义 | 默认值 |
|---|---|---:|
| `NUM_REGISTER_TOKENS` | 固定 shared register 数量 | 4 |
| `REGISTER_DIM` | register native width；0=full dim | 0 |
| `LEARNABLE_ROUTING` | layer-only router | 0 |
| `CLS_ATTN_SEMANTIC_KL_COEFF` | semantic KL 权重 | 0.0 |
| `SEMANTIC_KL_TEMPERATURE` | DINO target temperature | 0.10 |
| `SEMANTIC_KL_GRAD_SCOPE` | `tokens_router` / `full` | `tokens_router` |

---

## 测试

```bash
PYTHONPATH=. pytest -q tests/test_shared_dual_router.py
```

测试覆盖 dual stream、low-dimensional registers、layer router、DINO semantic target、one-layer-delayed semantic KL、register-only gradient isolation、attention layout 和 sampler API。
