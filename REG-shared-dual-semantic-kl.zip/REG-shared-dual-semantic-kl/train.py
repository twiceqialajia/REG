import argparse
import copy
from copy import deepcopy
import logging
import os
from pathlib import Path
from collections import OrderedDict
import json

import numpy as np
import torch
import torch.utils.checkpoint
from tqdm.auto import tqdm
from torch.utils.data import DataLoader

from accelerate import Accelerator, DistributedDataParallelKwargs
from accelerate.logging import get_logger
from accelerate.utils import ProjectConfiguration, set_seed

from models.sit import SiT_models
from loss import SILoss, build_dino_semantic_target
from utils import load_encoders
from register_aux import (
    add_register_aux_grads,
    compute_register_only_aux_grads,
    get_register_aux_parameters,
)

from dataset import CustomDataset
import math
from torchvision.utils import make_grid
from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from torchvision.transforms import Normalize

logger = get_logger(__name__)

CLIP_DEFAULT_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_DEFAULT_STD = (0.26862954, 0.26130258, 0.27577711)



def preprocess_raw_image(x, enc_type):
    resolution = x.shape[-1]
    if 'clip' in enc_type:
        x = x / 255.
        x = torch.nn.functional.interpolate(x, 224 * (resolution // 256), mode='bicubic')
        x = Normalize(CLIP_DEFAULT_MEAN, CLIP_DEFAULT_STD)(x)
    elif 'mocov3' in enc_type or 'mae' in enc_type:
        x = x / 255.
        x = Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)(x)
    elif 'dinov2' in enc_type:
        x = x / 255.
        x = Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)(x)
        x = torch.nn.functional.interpolate(x, 224 * (resolution // 256), mode='bicubic')
    elif 'dinov1' in enc_type:
        x = x / 255.
        x = Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)(x)
    elif 'jepa' in enc_type:
        x = x / 255.
        x = Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)(x)
        x = torch.nn.functional.interpolate(x, 224 * (resolution // 256), mode='bicubic')

    return x


def array2grid(x):
    nrow = round(math.sqrt(x.size(0)))
    x = make_grid(x.clamp(0, 1), nrow=nrow, value_range=(0, 1))
    x = x.mul(255).add_(0.5).clamp_(0, 255).permute(1, 2, 0).to('cpu', torch.uint8).numpy()
    return x


@torch.no_grad()
def sample_posterior(moments, latents_scale=1., latents_bias=0.):
    device = moments.device
    
    mean, std = torch.chunk(moments, 2, dim=1)
    z = mean + std * torch.randn_like(mean)
    z = (z * latents_scale + latents_bias) 
    return z 


@torch.no_grad()
def update_ema(ema_model, model, decay=0.9999):
    """
    Step the EMA model towards the current model.
    """
    ema_params = OrderedDict(ema_model.named_parameters())
    model_params = OrderedDict(model.named_parameters())

    for name, param in model_params.items():
        name = name.replace("module.", "")
        # TODO: Consider applying only to params that require_grad to avoid small numerical changes of pos_embed
        ema_params[name].mul_(decay).add_(param.data, alpha=1 - decay)


def create_logger(logging_dir):
    """
    Create a logger that writes to a log file and stdout.
    """
    logging.basicConfig(
        level=logging.INFO,
        format='[\033[34m%(asctime)s\033[0m] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[logging.StreamHandler(), logging.FileHandler(f"{logging_dir}/log.txt")]
    )
    logger = logging.getLogger(__name__)
    return logger


def requires_grad(model, flag=True):
    """
    Set requires_grad flag for all parameters in a model.
    """
    for p in model.parameters():
        p.requires_grad = flag



#################################################################################
#                                  Training Loop                                #
#################################################################################

def main(args):    
    # set accelerator
    logging_dir = Path(args.output_dir, args.logging_dir)
    accelerator_project_config = ProjectConfiguration(
        project_dir=args.output_dir, logging_dir=logging_dir
        )

    accelerator = Accelerator(
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        mixed_precision=args.mixed_precision,
        log_with=args.report_to,
        project_config=accelerator_project_config,
        kwargs_handlers=[DistributedDataParallelKwargs(find_unused_parameters=True)]
    )

    if accelerator.is_main_process:
        os.makedirs(args.output_dir, exist_ok=True)  # Make results folder (holds all experiment subfolders)
        save_dir = os.path.join(args.output_dir, args.exp_name)
        os.makedirs(save_dir, exist_ok=True)
        args_dict = vars(args)
        # Save to a JSON file
        json_dir = os.path.join(save_dir, "args.json")
        with open(json_dir, 'w') as f:
            json.dump(args_dict, f, indent=4)
        checkpoint_dir = f"{save_dir}/checkpoints"  # Stores saved model checkpoints
        os.makedirs(checkpoint_dir, exist_ok=True)
        logger = create_logger(save_dir)
        logger.info(f"Experiment directory created at {save_dir}")
    device = accelerator.device
    if torch.backends.mps.is_available():
        accelerator.native_amp = False    
    if args.seed is not None:
        set_seed(args.seed + accelerator.process_index)
    
    # Create model:
    assert args.resolution % 8 == 0, "Image size must be divisible by 8 (for the VAE encoder)."
    latent_size = args.resolution // 8

    needs_encoder = args.use_reg or args.use_repa
    if needs_encoder:
        encoders, encoder_types, architectures = load_encoders(
            args.enc_type,
            device,
            args.resolution,
            encoder_path=args.encoder_path,
            )
    else:
        encoders, encoder_types, architectures = [], [], []
    z_dims = [encoder.embed_dim for encoder in encoders] if encoders else [args.encoder_embed_dim]
    args.encoder_embed_dim = z_dims[0]
    block_kwargs = {"fused_attn": args.fused_attn, "qk_norm": args.qk_norm}
    model = SiT_models[args.model](
        input_size=latent_size,
        num_classes=args.num_classes,
        use_cfg=(args.cfg_prob > 0),
        z_dims=z_dims,
        encoder_depth=args.encoder_depth,
        class_dropout_prob=args.cfg_prob,
        use_reg=args.use_reg,
        use_repa=args.use_repa,
        num_register_tokens=args.num_register_tokens,
        register_dim=args.register_dim,
        register_mlp_ratio=args.register_mlp_ratio,
        dual_norm_type=args.dual_norm_type,
        learnable_register_routing=args.learnable_register_routing,
        router_temperature=args.router_temperature,
        router_hard=args.router_hard,
        router_hard_threshold=args.router_hard_threshold,
        router_init_gate=args.router_init_gate,
        router_budget_type=args.router_budget_type,
        router_budget_target=args.router_budget_target,
        **block_kwargs,
    )

    model = model.to(device)
    model_num_patches = int(model.x_embedder.num_patches)
    ema = deepcopy(model).to(device)  # Create an EMA of the model for use after training
    requires_grad(ema, False)
    
    latents_scale = torch.tensor(
        [0.18215, 0.18215, 0.18215, 0.18215]
        ).view(1, 4, 1, 1).to(device)
    latents_bias = torch.tensor(
        [0., 0., 0., 0.]
        ).view(1, 4, 1, 1).to(device)

    # create loss function
    loss_fn = SILoss(
        prediction=args.prediction,
        path_type=args.path_type, 
        encoders=encoders,
        accelerator=accelerator,
        latents_scale=latents_scale,
        latents_bias=latents_bias,
        weighting=args.weighting,
        use_reg=args.use_reg,
        use_repa=args.use_repa,
        shared_timestep_per_batch=args.shared_timestep_per_batch,
    )
    if accelerator.is_main_process:
        logger.info(f"SiT Parameters: {sum(p.numel() for p in model.parameters()):,}")
        logger.info(
            "Shared-register dual stream: model=%s, registers=%d, register_dim=%d, "
            "norm=%s, layer_router=%s, budget=%s/%.3f, semantic_kl=%.4f (tau=%.3f, scope=%s), REG=%s, REPA=%s",
            args.model,
            model.num_register_tokens,
            model.register_dim,
            model.dual_norm_type,
            model.learnable_register_routing,
            args.router_budget_type,
            args.router_budget_target,
            args.cls_attention_semantic_kl_coeff,
            args.semantic_kl_temperature,
            args.semantic_kl_grad_scope,
            model.use_reg,
            model.use_repa,
        )
    
    # Setup optimizer (we used default Adam betas=(0.9, 0.999) and a constant learning rate of 1e-4 in our paper):
    if args.allow_tf32:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        betas=(args.adam_beta1, args.adam_beta2),
        weight_decay=args.adam_weight_decay,
        eps=args.adam_epsilon,
    )    
    
    # Setup data:
    train_dataset = CustomDataset(
        args.data_dir,
        images_subdir=args.images_subdir,
        latents_subdir=args.latents_subdir,
    )
    local_batch_size = int(args.batch_size // accelerator.num_processes)
    train_dataloader = DataLoader(
        train_dataset,
        batch_size=local_batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True
    )
    if accelerator.is_main_process:
        logger.info(f"Dataset contains {len(train_dataset):,} images ({args.data_dir})")
    
    # Prepare models for training:
    update_ema(ema, model, decay=0)  # Ensure EMA is initialized with synced weights
    model.train()  # important! This enables embedding dropout for classifier-free guidance
    ema.eval()  # EMA model should always be in eval mode
    
    # resume:
    global_step = 0
    if args.resume_step > 0:
        ckpt_name = str(args.resume_step).zfill(7) +'.pt'
        ckpt = torch.load(
            f'{os.path.join(args.output_dir, args.exp_name)}/checkpoints/{ckpt_name}',
            map_location='cpu',
            )
        model.load_state_dict(ckpt['model'])
        ema.load_state_dict(ckpt['ema'])
        optimizer.load_state_dict(ckpt['opt'])
        global_step = ckpt['steps']

    model, optimizer, train_dataloader = accelerator.prepare(
        model, optimizer, train_dataloader
    )
    register_aux_named_params = get_register_aux_parameters(
        model, accelerator, scope=args.semantic_kl_grad_scope
    )
    if args.cls_attention_semantic_kl_coeff > 0 and not register_aux_named_params:
        raise RuntimeError("No register parameters found for semantic-KL supervision")
    if accelerator.is_main_process and args.cls_attention_semantic_kl_coeff > 0:
        logger.info(
            "DINO semantic KL gradients are restricted to %d tensors (scope=%s). "
            "The KL graph is built in a separate forward after main backward.",
            len(register_aux_named_params),
            args.semantic_kl_grad_scope,
        )

    if accelerator.is_main_process:
        tracker_config = vars(copy.deepcopy(args))
        accelerator.init_trackers(
            project_name="REG",
            config=tracker_config,
            init_kwargs={
                "wandb": {"name": f"{args.exp_name}"}
            },
        )

        
    progress_bar = tqdm(
        range(0, args.max_train_steps),
        initial=global_step,
        desc="Steps",
        # Only show the progress bar once on each machine.
        disable=not accelerator.is_local_main_process,
    )

    # Labels to condition the model with (feel free to change):
    sample_batch_size = 64 // accelerator.num_processes
    gt_raw_images, gt_xs, _ = next(iter(train_dataloader))
    assert gt_raw_images.shape[-1] == args.resolution
    gt_xs = gt_xs[:sample_batch_size]
    gt_xs = sample_posterior(
        gt_xs.to(device), latents_scale=latents_scale, latents_bias=latents_bias
        )
    ys = torch.randint(1000, size=(sample_batch_size,), device=device)
    ys = ys.to(device)
    # Create sampling noise:
    n = ys.size(0)
    xT = torch.randn((n, 4, latent_size, latent_size), device=device)
        
    for epoch in range(args.epochs):
        model.train()
        for raw_image, x, y in train_dataloader:
            raw_image = raw_image.to(device)
            x = x.squeeze(dim=1).to(device)
            y = y.to(device)
            cls_token = None
            zs = None
            dino_semantic_target = None
            if args.legacy:
                # In our early experiments, we accidentally apply label dropping twice: 
                # once in train.py and once in sit.py. 
                # We keep this option for exact reproducibility with previous runs.
                drop_ids = torch.rand(y.shape[0], device=y.device) < args.cfg_prob
                labels = torch.where(drop_ids, args.num_classes, y)
            else:
                labels = y
            with torch.no_grad():
                x = sample_posterior(x, latents_scale=latents_scale, latents_bias=latents_bias)
                if needs_encoder:
                    zs = [] if args.use_repa else None
                with accelerator.autocast(), torch.no_grad():
                    for encoder, encoder_type, arch in zip(encoders, encoder_types, architectures):
                        raw_image_ = preprocess_raw_image(raw_image, encoder_type)
                        z = encoder.forward_features(raw_image_)
                        if 'dinov2' in encoder_type:
                            patch_tokens = z['x_norm_patchtokens']
                            encoder_cls_token = z['x_norm_clstoken']
                            if args.use_reg:
                                cls_token = encoder_cls_token
                            if args.cls_attention_semantic_kl_coeff > 0:
                                # Clean DINO CLS<->patch cosine similarities define
                                # the semantic spatial target. Temperature controls
                                # target sharpness; DINO/SiT grid mismatch is resized.
                                dino_semantic_target = build_dino_semantic_target(
                                    encoder_cls_token,
                                    patch_tokens,
                                    target_num_patches=model_num_patches,
                                    temperature=args.semantic_kl_temperature,
                                )
                            if args.use_repa:
                                # Match model ordering but exclude unsupervised register tokens.
                                dense_z = (
                                    torch.cat([encoder_cls_token.unsqueeze(1), patch_tokens], dim=1)
                                    if args.use_reg else patch_tokens
                                )
                                zs.append(dense_z)
                        else:
                            raise NotImplementedError("Only DINOv2 is supported for REG ablations")

            with accelerator.accumulate(model):
                model_kwargs = dict(y=labels)
                (
                    loss1,
                    proj_loss1,
                    time_input,
                    noises,
                    noises_cls,
                    loss2,
                    budget_loss_raw,
                    router_entropy_raw,
                    router_stats,
                ) = loss_fn(
                    model, x, model_kwargs, zs=zs, cls_token=cls_token
                )
                loss_mean = loss1.mean()
                loss_mean_cls = loss2.mean() * args.cls_coeff
                proj_loss_mean = proj_loss1.mean() * args.proj_coeff
                budget_loss = budget_loss_raw * args.budget_coeff
                router_binarization_loss = (
                    router_entropy_raw * args.router_binarization_coeff
                )
                main_loss = (
                    loss_mean
                    + proj_loss_mean
                    + loss_mean_cls
                    + budget_loss
                    + router_binarization_loss
                )

                # 1) Backprop the ordinary FM/CLS/REPA/router objectives first.
                # This releases the large main computation graph.
                accelerator.backward(main_loss)

                # 2) Build a *separate* lightweight auxiliary graph for the
                # DINO-guided CLS->patch semantic KL.  The KL is measured from
                # layer 1 onward (one-layer delay), and its gradients are then
                # restricted to the register branch / optional router.  No
                # retain_graph=True is needed, avoiding the old entropy OOM.
                semantic_kl_raw = main_loss.detach() * 0.0
                semantic_kl_loss = main_loss.detach() * 0.0
                semantic_kl_stats = None
                if args.cls_attention_semantic_kl_coeff > 0:
                    if dino_semantic_target is None:
                        raise RuntimeError(
                            "Semantic KL is enabled but no DINO semantic target was built"
                        )
                    semantic_kl_raw, semantic_kl_stats = loss_fn.semantic_kl_loss(
                        model,
                        x,
                        semantic_target=dino_semantic_target,
                        model_kwargs=model_kwargs,
                        cls_token=cls_token,
                        time_input=time_input,
                        noises=noises,
                        noises_cls=noises_cls,
                    )
                    semantic_kl_loss = (
                        semantic_kl_raw * args.cls_attention_semantic_kl_coeff
                    )
                    aux_grads = compute_register_only_aux_grads(
                        semantic_kl_loss,
                        register_aux_named_params,
                        accelerator,
                    )
                    add_register_aux_grads(
                        register_aux_named_params, aux_grads, accelerator
                    )
                    # Free the second graph before clipping/step.
                    del aux_grads

                total_loss_for_log = main_loss.detach() + semantic_kl_loss.detach()

                if accelerator.sync_gradients:
                    params_to_clip = model.parameters()
                    grad_norm = accelerator.clip_grad_norm_(
                        params_to_clip, args.max_grad_norm
                    )
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)


                if accelerator.sync_gradients:
                    update_ema(ema, model) # change ema function
            
            ### enter
            if accelerator.sync_gradients:
                progress_bar.update(1)
                global_step += 1                
            if global_step % args.checkpointing_steps == 0 and global_step > 0:
                if accelerator.is_main_process:
                    checkpoint = {
                        "model": accelerator.unwrap_model(model).state_dict(),
                        "ema": ema.state_dict(),
                        "opt": optimizer.state_dict(),
                        "args": args,
                        "steps": global_step,
                    }
                    checkpoint_path = f"{checkpoint_dir}/{global_step:07d}.pt"
                    torch.save(checkpoint, checkpoint_path)
                    logger.info(f"Saved checkpoint to {checkpoint_path}")

            if (global_step == 1 or (global_step % args.sampling_steps == 0 and global_step > 0)):
                logging.info("Generating EMA samples done.")

            logs = {
                "loss_final": accelerator.gather(total_loss_for_log).mean().detach().item(),
                "loss_mean": accelerator.gather(loss_mean).mean().detach().item(),
                "proj_loss": accelerator.gather(proj_loss_mean).mean().detach().item(),
                "loss_mean_cls": accelerator.gather(loss_mean_cls).mean().detach().item(),
                "budget_loss": accelerator.gather(budget_loss).mean().detach().item(),
                "router_bin_loss": accelerator.gather(router_binarization_loss).mean().detach().item(),
                "cls_attn_semantic_kl_loss": accelerator.gather(semantic_kl_loss).mean().detach().item(),
                "cls_attn_semantic_kl": accelerator.gather(semantic_kl_raw.detach()).mean().item(),
                "router_usage": float(router_stats["mean_usage"]),
                "router_active_layers": float(router_stats["expected_active_layers"]),
                "router_active_regs": float(router_stats["expected_active_registers"]),
                "router_entropy": float(router_stats["router_entropy"]),
                "grad_norm": float(grad_norm) if accelerator.sync_gradients else 0.0,
            }

            log_message = ", ".join(f"{key}: {value:.6f}" for key, value in logs.items())
            logging.info(f"Step: {global_step}, Training Logs: {log_message}")

            progress_bar.set_postfix(**logs)
            accelerator.log(logs, step=global_step)

            if global_step >= args.max_train_steps:
                break
        if global_step >= args.max_train_steps:
            break

    model.eval()  # important! This disables randomized embedding dropout
    # do any sampling/FID calculation/etc. with ema (or model) in eval mode ...
    
    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        logger.info("Done!")
    accelerator.end_training()

def parse_args(input_args=None):
    parser = argparse.ArgumentParser(description="Training")

    # logging:
    parser.add_argument("--output-dir", type=str, default="exps")
    parser.add_argument("--exp-name", type=str, default=None)
    parser.add_argument("--logging-dir", type=str, default="logs")
    parser.add_argument("--report-to", type=str, default="wandb")
    parser.add_argument("--sampling-steps", type=int, default=10000)
    parser.add_argument("--resume-step", type=int, default=0)

    # model
    parser.add_argument("--model", type=str)
    parser.add_argument("--num-classes", type=int, default=1000)
    parser.add_argument("--encoder-depth", type=int, default=8)
    parser.add_argument("--fused-attn", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--qk-norm",  action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--ops-head", type=int, default=16)
    parser.add_argument(
        "--num-register-tokens",
        type=int,
        default=4,
        help="Maximum number of shared register slots.",
    )
    parser.add_argument(
        "--register-dim",
        type=int,
        default=0,
        help=(
            "Native register width. 0 means the model hidden size. Set e.g. "
            "256 for the low-dimensional register stream."
        ),
    )
    parser.add_argument(
        "--register-mlp-ratio", type=float, default=4.0
    )
    parser.add_argument(
        "--dual-norm-type",
        type=str.lower,
        choices=["rmsnorm", "layernorm"],
        default="rmsnorm",
        help="Separate normalization type for patch/CLS and register streams.",
    )
    parser.add_argument(
        "--learnable-register-routing",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Learn one timestep-independent activation weight per Transformer "
            "layer. The fixed register count is shared by all active layers."
        ),
    )
    parser.add_argument("--router-temperature", type=float, default=0.10)
    parser.add_argument(
        "--router-hard", action=argparse.BooleanOptionalAction, default=False
    )
    parser.add_argument("--router-hard-threshold", type=float, default=0.5)
    parser.add_argument(
        "--router-init-gate",
        type=float,
        default=0.95,
        help=(
            "Initial soft layer gate in (0,1). Values near 1 start close to "
            "the ordinary all-layer shared-register baseline."
        ),
    )
    parser.add_argument(
        "--router-budget-type",
        type=str.lower,
        choices=["target", "l1", "none"],
        default="target",
    )
    parser.add_argument(
        "--router-budget-target",
        type=float,
        default=0.50,
        help="Target fraction of Transformer layers using the fixed register set.",
    )
    parser.add_argument(
        "--budget-coeff",
        type=float,
        default=0.01,
        help="Weight of the router budget loss.",
    )
    parser.add_argument(
        "--router-binarization-coeff",
        type=float,
        default=0.0,
        help="Optional entropy penalty encouraging gates toward 0/1.",
    )
    parser.add_argument(
        "--shared-timestep-per-batch",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Use one sampled t for the whole local batch. This is optional; it "
            "makes a learned hard route homogeneous within the batch for later "
            "physical compaction experiments."
        ),
    )

    # dataset
    parser.add_argument(
        "--data-dir", type=str,
        default=os.environ.get("DATA_DIR", "../data/imagenet256"),
    )
    parser.add_argument(
        "--images-subdir", type=str,
        default=os.environ.get("IMAGES_SUBDIR", "imagenet_256_vae"),
    )
    parser.add_argument(
        "--latents-subdir", type=str,
        default=os.environ.get("LATENTS_SUBDIR", "vae-sd"),
    )
    parser.add_argument("--resolution", type=int, choices=[256, 512], default=256)
    parser.add_argument("--batch-size", type=int, default=8)#256

    # precision
    parser.add_argument("--allow-tf32", action="store_true")
    parser.add_argument("--mixed-precision", type=str, default="fp16", choices=["no", "fp16", "bf16"])

    # optimization
    parser.add_argument("--epochs", type=int, default=1400)
    parser.add_argument("--max-train-steps", type=int, default=1000000)
    parser.add_argument("--checkpointing-steps", type=int, default=10000)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=1)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--adam-beta1", type=float, default=0.9, help="The beta1 parameter for the Adam optimizer.")
    parser.add_argument("--adam-beta2", type=float, default=0.999, help="The beta2 parameter for the Adam optimizer.")
    parser.add_argument("--adam-weight-decay", type=float, default=0., help="Weight decay to use.")
    parser.add_argument("--adam-epsilon", type=float, default=1e-08, help="Epsilon value for the Adam optimizer")
    parser.add_argument("--max-grad-norm", default=1.0, type=float, help="Max gradient norm.")

    # seed
    parser.add_argument("--seed", type=int, default=0)

    # cpu
    parser.add_argument("--num-workers", type=int, default=4)

    # loss
    parser.add_argument("--path-type", type=str, default="linear", choices=["linear", "cosine"])
    parser.add_argument("--prediction", type=str, default="v", choices=["v"]) # currently we only support v-prediction
    parser.add_argument("--cfg-prob", type=float, default=0.1)
    parser.add_argument("--enc-type", type=str, default='dinov2-vit-b')
    parser.add_argument(
        "--encoder-path", type=str, default=os.environ.get("ENCODER_PATH"),
        help="Local Hugging Face DINOv2 directory (PyTorch .bin supported).",
    )
    parser.add_argument(
        "--encoder-embed-dim", type=int, default=768,
        help="Only used to build a no-REG/no-REPA baseline without loading DINO.",
    )
    parser.add_argument("--proj-coeff", type=float, default=0.5)
    parser.add_argument("--weighting", default="uniform", type=str, help="Max gradient norm.")
    parser.add_argument("--legacy", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--cls-coeff", "--cls", dest="cls_coeff", type=float, default=0.03)
    parser.add_argument(
        "--cls-attention-semantic-kl-coeff",
        type=float,
        default=0.0,
        help=(
            "Weight for DINO-guided CLS->patch semantic KL. A clean DINO "
            "CLS-to-patch cosine distribution is the target; the KL gradient "
            "is restricted to register-specific parameters / optional router."
        ),
    )
    parser.add_argument(
        "--semantic-kl-temperature",
        type=float,
        default=0.10,
        help=(
            "Temperature used when converting clean DINO CLS-patch cosine "
            "similarities into the semantic target. Smaller = sharper target."
        ),
    )
    parser.add_argument(
        "--semantic-kl-grad-scope",
        choices=["tokens_router", "full"],
        default="tokens_router",
        help=(
            "Which register parameters receive the semantic-KL auxiliary "
            "gradient. tokens_router is the lowest-memory option; full also "
            "updates register-specific MLP/AdaLN/Norm/projections. The KL uses "
            "a separate post-main-backward forward, so neither mode retains the "
            "main graph."
        ),
    )
    if input_args is not None:
        args = parser.parse_args(input_args)
    else:
        args = parser.parse_args()

    # All experiments in this branch start from shared registers only.
    args.use_reg = True
    args.use_repa = True
    if args.num_register_tokens <= 0:
        parser.error("--num-register-tokens must be positive")
    if args.register_dim < 0:
        parser.error("--register-dim must be >= 0")
    if not 0 <= args.router_budget_target <= 1:
        parser.error("--router-budget-target must be in [0,1]")
    if not 0 < args.router_init_gate < 1:
        parser.error("--router-init-gate must be in (0,1)")
    if args.budget_coeff < 0 or args.router_binarization_coeff < 0:
        parser.error("budget coefficients must be non-negative")
    if args.cls_attention_semantic_kl_coeff < 0:
        parser.error("--cls-attention-semantic-kl-coeff must be non-negative")
    if args.semantic_kl_temperature <= 0:
        parser.error("--semantic-kl-temperature must be > 0")
    if args.exp_name is None:
        dim_tag = "full" if args.register_dim == 0 else str(args.register_dim)
        route_tag = "router" if args.learnable_register_routing else "fixed"
        sem_tag = (
            f"-semkl{args.cls_attention_semantic_kl_coeff:g}-tau{args.semantic_kl_temperature:g}"
            if args.cls_attention_semantic_kl_coeff > 0 else ""
        )
        args.exp_name = (
            f"shared-dual-reg{args.num_register_tokens}-dim{dim_tag}-"
            f"{route_tag}{sem_tag}"
        )
    if not args.enc_type:
        parser.error("--enc-type is required when REG or REPA is enabled")
    return args

if __name__ == "__main__":
    args = parse_args()
    
    main(args)
