# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# GLIDE: https://github.com/openai/glide-text2im
# MAE: https://github.com/facebookresearch/mae/blob/main/models_mae.py
# --------------------------------------------------------

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.vision_transformer import PatchEmbed, Attention, Mlp


def build_mlp(hidden_size, projector_dim, z_dim):
    return nn.Sequential(
        nn.Linear(hidden_size, projector_dim),
        nn.SiLU(),
        nn.Linear(projector_dim, projector_dim),
        nn.SiLU(),
        nn.Linear(projector_dim, z_dim),
    )


def modulate(x, shift, scale):
    return x * (1 + scale.unsqueeze(1)) + shift.unsqueeze(1)


def make_norm(norm_type, dim):
    norm_type = norm_type.lower()
    if norm_type == "rmsnorm":
        # Separate affine parameters for patch/CLS and register streams.
        return nn.RMSNorm(dim, eps=1e-6, elementwise_affine=True)
    if norm_type == "layernorm":
        return nn.LayerNorm(dim, elementwise_affine=False, eps=1e-6)
    raise ValueError(f"Unsupported norm_type={norm_type}")


#################################################################################
#               Embedding Layers for Timesteps and Class Labels                 #
#################################################################################


class TimestepEmbedder(nn.Module):
    """Embeds scalar timesteps into vector representations."""

    def __init__(self, hidden_size, frequency_embedding_size=256):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(frequency_embedding_size, hidden_size, bias=True),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size, bias=True),
        )
        self.frequency_embedding_size = frequency_embedding_size

    @staticmethod
    def positional_embedding(t, dim, max_period=10000):
        half = dim // 2
        freqs = torch.exp(
            -math.log(max_period)
            * torch.arange(start=0, end=half, dtype=torch.float32)
            / half
        ).to(device=t.device)
        args = t[:, None].float() * freqs[None]
        embedding = torch.cat([torch.cos(args), torch.sin(args)], dim=-1)
        if dim % 2:
            embedding = torch.cat(
                [embedding, torch.zeros_like(embedding[:, :1])], dim=-1
            )
        return embedding

    def forward(self, t):
        t_freq = self.positional_embedding(
            t, dim=self.frequency_embedding_size
        ).to(t.dtype)
        return self.mlp(t_freq)


class LabelEmbedder(nn.Module):
    """Embeds class labels and handles classifier-free label dropout."""

    def __init__(self, num_classes, hidden_size, dropout_prob):
        super().__init__()
        use_cfg_embedding = dropout_prob > 0
        self.embedding_table = nn.Embedding(
            num_classes + use_cfg_embedding, hidden_size
        )
        self.num_classes = num_classes
        self.dropout_prob = dropout_prob

    def token_drop(self, labels, force_drop_ids=None):
        if force_drop_ids is None:
            drop_ids = (
                torch.rand(labels.shape[0], device=labels.device)
                < self.dropout_prob
            )
        else:
            drop_ids = force_drop_ids == 1
        return torch.where(drop_ids, self.num_classes, labels)

    def forward(self, labels, train, force_drop_ids=None):
        use_dropout = self.dropout_prob > 0
        if (train and use_dropout) or (force_drop_ids is not None):
            labels = self.token_drop(labels, force_drop_ids)
        return self.embedding_table(labels)


#################################################################################
#                       Learnable register routing                              #
#################################################################################


class LearnableLayerRouter(nn.Module):
    """One learnable register-activation weight per Transformer layer.

    The register count is fixed.  Every layer owns one scalar gate g_l in [0, 1]
    that is shared by all register tokens and is independent of timestep.  This
    deliberately keeps the router low-capacity and directly answers *where in
    depth* registers are useful.

    A soft gate is used during training.  `hard=True` applies a straight-through
    binary gate in the register residual path; attention keeps the soft prior in
    training and becomes binary in evaluation/sampling.
    """

    def __init__(
        self,
        depth,
        num_register_tokens,
        temperature=0.10,
        hard=False,
        hard_threshold=0.5,
        init_gate=0.95,
        budget_type="target",
        budget_target=0.50,
    ):
        super().__init__()
        if depth <= 0 or num_register_tokens <= 0:
            raise ValueError("Router requires positive depth and register count")
        if temperature <= 0:
            raise ValueError("router temperature must be > 0")
        if not 0 < hard_threshold < 1:
            raise ValueError("router hard threshold must be in (0,1)")
        if not 0 < init_gate < 1:
            raise ValueError("router init_gate must be in (0,1)")
        if budget_type not in {"target", "l1", "none"}:
            raise ValueError("budget_type must be target, l1, or none")
        if not 0 <= budget_target <= 1:
            raise ValueError("budget_target must be in [0,1]")

        # Parameterization is chosen so sigmoid(logit / temperature) starts at
        # exactly init_gate, independent of temperature.
        init_logit = temperature * math.log(init_gate / (1.0 - init_gate))
        self.layer_logits = nn.Parameter(
            torch.full((depth,), float(init_logit), dtype=torch.float32)
        )
        self.depth = int(depth)
        self.num_register_tokens = int(num_register_tokens)
        self.temperature = float(temperature)
        self.hard = bool(hard)
        self.hard_threshold = float(hard_threshold)
        self.budget_type = budget_type
        self.budget_target = float(budget_target)

    def forward(self, t=None, batch_size=None, dtype=None, device=None):
        # t is accepted only for a stable caller API; routing is intentionally
        # independent of timestep.
        if batch_size is None:
            if t is None:
                raise ValueError("batch_size or t must be provided")
            batch_size = int(t.shape[0])
        if device is None:
            device = self.layer_logits.device
        if dtype is None:
            dtype = t.dtype if t is not None else self.layer_logits.dtype

        soft_layer_gates = torch.sigmoid(
            self.layer_logits.float() / self.temperature
        ).to(device=device, dtype=dtype)  # [L]
        hard_layer_mask = soft_layer_gates >= self.hard_threshold

        if self.hard:
            binary = hard_layer_mask.to(dtype=soft_layer_gates.dtype)
            layer_gates = (
                binary.detach() - soft_layer_gates.detach() + soft_layer_gates
            )
            attention_layer_gates = soft_layer_gates if self.training else binary
        else:
            layer_gates = soft_layer_gates
            attention_layer_gates = soft_layer_gates

        # The same layer gate controls all fixed shared registers.
        gates = layer_gates[None, :, None].expand(
            batch_size, self.depth, self.num_register_tokens
        )
        attention_gates = attention_layer_gates[None, :, None].expand_as(gates)

        mean_usage = soft_layer_gates.float().mean()
        if self.budget_type == "target":
            budget_loss = (mean_usage - self.budget_target) ** 2
        elif self.budget_type == "l1":
            budget_loss = mean_usage
        else:
            budget_loss = mean_usage * 0.0

        eps = 1e-6
        p = soft_layer_gates.float().clamp(eps, 1 - eps)
        entropy = -(p * torch.log(p) + (1 - p) * torch.log(1 - p)).mean()
        aux = {
            "budget_loss": budget_loss,
            "router_entropy": entropy,
            "mean_usage": mean_usage.detach(),
            "expected_active_layers": soft_layer_gates.float().sum().detach(),
            "expected_active_registers": (
                mean_usage.detach() * float(self.num_register_tokens)
            ),
            "usage_by_layer": soft_layer_gates.float().detach(),
            "usage_by_register": mean_usage.detach().expand(
                self.num_register_tokens
            ).clone(),
            "layer_logits": self.layer_logits.detach(),
            "soft_layer_gates": soft_layer_gates,
            "soft_gates": gates,
            "hard_mask": hard_layer_mask[None, :, None].expand_as(gates),
        }
        return gates, attention_gates, aux


#################################################################################
#                            Dual-stream SiT block                              #
#################################################################################


class DualStreamSiTBlock(nn.Module):
    """SiT block with shared attention and specialized register processing.

    Patch/CLS tokens and registers have separate normalization, adaLN and MLP
    modules.  Attention weights are shared.  A low-dimensional register state is
    supported by projecting registers into the main hidden dimension only for
    shared self-attention, then projecting the attention result back to the
    register dimension.
    """

    def __init__(
        self,
        hidden_size,
        num_heads,
        mlp_ratio=4.0,
        register_dim=None,
        register_mlp_ratio=4.0,
        norm_type="rmsnorm",
        **block_kwargs,
    ):
        super().__init__()
        self.hidden_size = int(hidden_size)
        self.register_dim = int(register_dim or hidden_size)
        self.num_heads = int(num_heads)

        # Separate normalization parameters/operations.
        self.patch_norm1 = make_norm(norm_type, self.hidden_size)
        self.patch_norm2 = make_norm(norm_type, self.hidden_size)
        self.register_norm1 = make_norm(norm_type, self.register_dim)
        self.register_norm2 = make_norm(norm_type, self.register_dim)

        # Exactly one attention module is shared by patch/CLS/register tokens.
        self.attn = Attention(
            self.hidden_size,
            num_heads=num_heads,
            qkv_bias=True,
            qk_norm=block_kwargs.get("qk_norm", False),
        )
        if "fused_attn" in block_kwargs:
            self.attn.fused_attn = block_kwargs["fused_attn"]

        self.register_to_attention = (
            nn.Identity()
            if self.register_dim == self.hidden_size
            else nn.Linear(self.register_dim, self.hidden_size, bias=False)
        )
        self.attention_to_register = (
            nn.Identity()
            if self.register_dim == self.hidden_size
            else nn.Linear(self.hidden_size, self.register_dim, bias=False)
        )

        # Fully separate MLPs.  This is deliberately stronger separation than
        # the compact shared-hidden MLP variant in the referenced paper and is
        # particularly useful for low-dimensional registers.
        patch_mlp_hidden = int(self.hidden_size * mlp_ratio)
        register_mlp_hidden = max(
            1, int(self.register_dim * register_mlp_ratio)
        )
        approx_gelu = lambda: nn.GELU(approximate="tanh")
        self.patch_mlp = Mlp(
            in_features=self.hidden_size,
            hidden_features=patch_mlp_hidden,
            act_layer=approx_gelu,
            drop=0,
        )
        self.register_mlp = Mlp(
            in_features=self.register_dim,
            hidden_features=register_mlp_hidden,
            act_layer=approx_gelu,
            drop=0,
        )

        # Completely separate adaLN parameter generators.  Both consume the
        # common conditioning vector c, but produce stream-specific transforms.
        self.patch_adaLN = nn.Sequential(
            nn.SiLU(),
            nn.Linear(self.hidden_size, 6 * self.hidden_size, bias=True),
        )
        self.register_adaLN = nn.Sequential(
            nn.SiLU(),
            nn.Linear(self.hidden_size, 6 * self.register_dim, bias=True),
        )

    def _shared_attention(
        self,
        x,
        register_range,
        register_soft_gate=None,
        semantic_target=None,
        return_attention=False,
        return_cls_patch_semantic_kl=False,
        use_cls_token=True,
    ):
        """Run shared attention and optionally compute DINO-guided CLS->patch KL.

        The auxiliary path computes only the CLS query row, never the full NxN
        attention matrix. Patch probabilities are normalized over image-patch
        keys only and compared with a clean-image DINO semantic distribution.
        Since the CLS query and patch keys entering block l were produced by
        preceding blocks, KL measured at block l provides the intended
        one-layer-delayed supervision to earlier register processing.
        """
        attn = self.attn
        batch, tokens, channels = x.shape
        qkv = attn.qkv(x).reshape(
            batch,
            tokens,
            3,
            attn.num_heads,
            channels // attn.num_heads,
        ).permute(2, 0, 3, 1, 4)
        q, k, v = qkv.unbind(0)
        q, k = attn.q_norm(q), attn.k_norm(k)

        attention_bias = None
        if register_soft_gate is not None and register_range is not None:
            start, end = register_range
            if register_soft_gate.shape != (batch, end - start):
                raise ValueError(
                    "register_soft_gate shape mismatch: "
                    f"got {tuple(register_soft_gate.shape)}, "
                    f"expected {(batch, end-start)}"
                )
            # log(g) acts as a differentiable key prior: g=1 is unchanged and
            # g->0 removes that register from all queries' attention support.
            attention_bias = x.new_zeros((batch, 1, 1, tokens))
            attention_bias[:, :, :, start:end] = torch.log(
                register_soft_gate.to(dtype=x.dtype).clamp_min(1e-5)
            )[:, None, None, :]

        cls_patch_semantic_kl = None
        if return_cls_patch_semantic_kl:
            if not use_cls_token:
                raise ValueError(
                    "CLS->patch semantic KL requires the REG/CLS token"
                )
            if semantic_target is None:
                raise ValueError(
                    "semantic_target is required for CLS->patch semantic KL"
                )
            patch_start = register_range[1]
            num_patches = tokens - patch_start
            if num_patches <= 1:
                raise ValueError(
                    "CLS->patch semantic KL requires at least two patches"
                )
            if semantic_target.shape != (batch, num_patches):
                raise ValueError(
                    "semantic_target shape mismatch: "
                    f"got {tuple(semantic_target.shape)}, "
                    f"expected {(batch, num_patches)}"
                )

            # Only the CLS query row: [B, heads, patches].  We average the
            # per-head patch distributions so heads remain free to specialize,
            # while their aggregate spatial attention is guided by DINO.
            cls_scores = (q[:, :, 0:1] * attn.scale) @ (
                k[:, :, patch_start:].transpose(-2, -1)
            )
            cls_patch_prob = cls_scores.float().softmax(dim=-1).squeeze(-2)
            pred_prob = cls_patch_prob.mean(dim=1).clamp_min(1e-8)
            pred_prob = pred_prob / pred_prob.sum(dim=-1, keepdim=True)

            target_prob = semantic_target.float().clamp_min(1e-8)
            target_prob = target_prob / target_prob.sum(dim=-1, keepdim=True)
            cls_patch_semantic_kl = (
                target_prob * (target_prob.log() - pred_prob.log())
            ).sum(dim=-1)

        if getattr(attn, "fused_attn", False) and not return_attention:
            dropout_p = attn.attn_drop.p if self.training else 0.0
            out = F.scaled_dot_product_attention(
                q,
                k,
                v,
                attn_mask=attention_bias,
                dropout_p=dropout_p,
                scale=attn.scale,
            )
            weights = None
        else:
            scores = (q * attn.scale) @ k.transpose(-2, -1)
            if attention_bias is not None:
                scores = scores + attention_bias
            weights = scores.softmax(dim=-1)
            weights_after_dropout = attn.attn_drop(weights)
            out = weights_after_dropout @ v

        out = out.transpose(1, 2).reshape(batch, tokens, channels)
        if hasattr(attn, "norm"):
            out = attn.norm(out)
        out = attn.proj_drop(attn.proj(out))
        return out, weights, cls_patch_semantic_kl

    def forward(
        self,
        patch_tokens,
        register_tokens,
        c,
        register_gate=None,
        register_soft_gate=None,
        semantic_target=None,
        use_cls_token=True,
        return_attention=False,
        return_cls_patch_semantic_kl=False,
    ):
        if register_tokens is None:
            raise ValueError("DualStreamSiTBlock requires register tokens")
        batch, num_registers, _ = register_tokens.shape
        if register_gate is None:
            register_gate = register_tokens.new_ones((batch, num_registers))
        if register_soft_gate is None:
            register_soft_gate = register_gate

        (
            p_shift_msa,
            p_scale_msa,
            p_gate_msa,
            p_shift_mlp,
            p_scale_mlp,
            p_gate_mlp,
        ) = self.patch_adaLN(c).chunk(6, dim=-1)

        # With a hard layer route at evaluation time, a disabled layer can
        # physically omit registers from attention and skip the register MLP.
        # Diagnostics keep the full sequence so token indexing remains stable.
        hard_layer_off = (
            (not self.training)
            and (not return_attention)
            and (not return_cls_patch_semantic_kl)
            and bool((register_soft_gate <= 0).all().item())
        )
        if hard_layer_off:
            patch_attn_input = modulate(
                self.patch_norm1(patch_tokens), p_shift_msa, p_scale_msa
            )
            patch_attn_output, _, _ = self._shared_attention(
                patch_attn_input,
                register_range=None,
                register_soft_gate=None,
                return_attention=False,
                return_cls_patch_semantic_kl=False,
                use_cls_token=use_cls_token,
            )
            patch_tokens = patch_tokens + p_gate_msa.unsqueeze(1) * patch_attn_output
            patch_mlp_output = self.patch_mlp(
                modulate(
                    self.patch_norm2(patch_tokens), p_shift_mlp, p_scale_mlp
                )
            )
            patch_tokens = patch_tokens + p_gate_mlp.unsqueeze(1) * patch_mlp_output
            return patch_tokens, register_tokens, None, None

        (
            r_shift_msa,
            r_scale_msa,
            r_gate_msa,
            r_shift_mlp,
            r_scale_mlp,
            r_gate_mlp,
        ) = self.register_adaLN(c).chunk(6, dim=-1)

        patch_attn_input = modulate(
            self.patch_norm1(patch_tokens), p_shift_msa, p_scale_msa
        )
        register_attn_native = modulate(
            self.register_norm1(register_tokens), r_shift_msa, r_scale_msa
        )
        register_attn_input = self.register_to_attention(register_attn_native)

        insert_at = int(bool(use_cls_token))
        attention_input = torch.cat(
            [
                patch_attn_input[:, :insert_at],
                register_attn_input,
                patch_attn_input[:, insert_at:],
            ],
            dim=1,
        )
        register_range = (insert_at, insert_at + num_registers)
        attention_output, attention, cls_patch_semantic_kl = self._shared_attention(
            attention_input,
            register_range,
            register_soft_gate=register_soft_gate,
            semantic_target=semantic_target,
            return_attention=return_attention,
            return_cls_patch_semantic_kl=return_cls_patch_semantic_kl,
            use_cls_token=use_cls_token,
        )
        patch_attn_output = torch.cat(
            [
                attention_output[:, :insert_at],
                attention_output[:, insert_at + num_registers :],
            ],
            dim=1,
        )
        register_attn_output = self.attention_to_register(
            attention_output[:, insert_at : insert_at + num_registers]
        )

        patch_tokens = patch_tokens + p_gate_msa.unsqueeze(1) * patch_attn_output
        register_tokens = register_tokens + (
            register_gate.unsqueeze(-1)
            * r_gate_msa.unsqueeze(1)
            * register_attn_output
        )

        patch_mlp_output = self.patch_mlp(
            modulate(self.patch_norm2(patch_tokens), p_shift_mlp, p_scale_mlp)
        )
        register_mlp_output = self.register_mlp(
            modulate(
                self.register_norm2(register_tokens),
                r_shift_mlp,
                r_scale_mlp,
            )
        )
        patch_tokens = patch_tokens + p_gate_mlp.unsqueeze(1) * patch_mlp_output
        register_tokens = register_tokens + (
            register_gate.unsqueeze(-1)
            * r_gate_mlp.unsqueeze(1)
            * register_mlp_output
        )
        return patch_tokens, register_tokens, attention, cls_patch_semantic_kl


class FinalLayer(nn.Module):
    """The final layer of SiT."""

    def __init__(
        self,
        hidden_size,
        patch_size,
        out_channels,
        cls_token_dim,
        use_reg=True,
    ):
        super().__init__()
        self.norm_final = nn.LayerNorm(
            hidden_size, elementwise_affine=False, eps=1e-6
        )
        self.linear = nn.Linear(
            hidden_size,
            patch_size * patch_size * out_channels,
            bias=True,
        )
        self.linear_cls = (
            nn.Linear(hidden_size, cls_token_dim, bias=True)
            if use_reg
            else None
        )
        self.adaLN_modulation = nn.Sequential(
            nn.SiLU(), nn.Linear(hidden_size, 2 * hidden_size, bias=True)
        )

    def forward(self, x, c, num_prefix_tokens=0, use_reg=False):
        shift, scale = self.adaLN_modulation(c).chunk(2, dim=-1)
        x = modulate(self.norm_final(x), shift, scale)
        cls_token = (
            self.linear_cls(x[:, 0]).unsqueeze(1) if use_reg else None
        )
        x = self.linear(x[:, num_prefix_tokens:])
        return x, None if cls_token is None else cls_token.squeeze(1)


#################################################################################
#                                  SiT Model                                    #
#################################################################################


class SiT(nn.Module):
    """SiT with shared registers, dual-stream processing and adaptive routing."""

    def __init__(
        self,
        path_type="edm",
        input_size=32,
        patch_size=2,
        in_channels=4,
        hidden_size=1152,
        decoder_hidden_size=768,
        encoder_depth=8,
        depth=28,
        num_heads=16,
        mlp_ratio=4.0,
        class_dropout_prob=0.1,
        num_classes=1000,
        use_cfg=False,
        z_dims=[768],
        projector_dim=2048,
        cls_token_dim=768,
        use_reg=True,
        use_repa=True,
        num_register_tokens=4,
        register_dim=0,
        register_mlp_ratio=4.0,
        dual_norm_type="rmsnorm",
        learnable_register_routing=False,
        router_temperature=0.10,
        router_hard=False,
        router_hard_threshold=0.5,
        router_init_gate=0.95,
        router_budget_type="target",
        router_budget_target=0.50,
        **block_kwargs,
    ):
        super().__init__()
        self.path_type = path_type
        self.in_channels = in_channels
        self.out_channels = in_channels
        self.patch_size = patch_size
        self.hidden_size = int(hidden_size)
        self.depth = int(depth)
        self.num_heads = int(num_heads)
        self.use_cfg = use_cfg
        self.num_classes = num_classes
        self.z_dims = z_dims
        self.encoder_depth = encoder_depth
        self.use_reg = bool(use_reg)
        self.use_repa = bool(use_repa)
        self.num_register_tokens = int(num_register_tokens)
        if self.num_register_tokens <= 0:
            raise ValueError("num_register_tokens must be positive")
        self.register_dim = int(register_dim) if int(register_dim) > 0 else self.hidden_size
        self.register_mlp_ratio = float(register_mlp_ratio)
        self.dual_norm_type = dual_norm_type
        self.learnable_register_routing = bool(learnable_register_routing)

        self.x_embedder = PatchEmbed(
            input_size,
            patch_size,
            in_channels,
            hidden_size,
            bias=True,
        )
        self.t_embedder = TimestepEmbedder(hidden_size)
        self.y_embedder = LabelEmbedder(
            num_classes, hidden_size, class_dropout_prob
        )
        num_patches = self.x_embedder.num_patches
        # Only the REG class token lives in the main stream. Registers have
        # their own learned state and no spatial positional embedding.
        self.num_main_prefix_tokens = int(self.use_reg)
        self.pos_embed = nn.Parameter(
            torch.zeros(
                1,
                num_patches + self.num_main_prefix_tokens,
                hidden_size,
            ),
            requires_grad=False,
        )
        self.register_tokens = nn.Parameter(
            torch.zeros(1, self.num_register_tokens, self.register_dim)
        )

        self.blocks = nn.ModuleList(
            [
                DualStreamSiTBlock(
                    hidden_size,
                    num_heads,
                    mlp_ratio=mlp_ratio,
                    register_dim=self.register_dim,
                    register_mlp_ratio=self.register_mlp_ratio,
                    norm_type=self.dual_norm_type,
                    **block_kwargs,
                )
                for _ in range(depth)
            ]
        )

        self.register_router = (
            LearnableLayerRouter(
                depth=depth,
                num_register_tokens=self.num_register_tokens,
                temperature=router_temperature,
                hard=router_hard,
                hard_threshold=router_hard_threshold,
                init_gate=router_init_gate,
                budget_type=router_budget_type,
                budget_target=router_budget_target,
            )
            if self.learnable_register_routing
            else None
        )

        self.projectors = nn.ModuleList(
            [build_mlp(hidden_size, projector_dim, z_dim) for z_dim in z_dims]
            if self.use_repa
            else []
        )
        z_dim = self.z_dims[0]
        cls_token_dim = z_dim
        self.final_layer = FinalLayer(
            decoder_hidden_size,
            patch_size,
            self.out_channels,
            cls_token_dim,
            use_reg=self.use_reg,
        )
        if self.use_reg:
            self.cls_projectors2 = nn.Linear(
                in_features=cls_token_dim,
                out_features=hidden_size,
                bias=True,
            )
            self.wg_norm = nn.LayerNorm(
                hidden_size, elementwise_affine=True, eps=1e-6
            )
        else:
            self.cls_projectors2 = None
            self.wg_norm = None

        self.initialize_weights()

    def initialize_weights(self):
        def _basic_init(module):
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)

        self.apply(_basic_init)

        pos_embed = get_2d_sincos_pos_embed(
            self.pos_embed.shape[-1],
            int(self.x_embedder.num_patches**0.5),
            cls_token=self.num_main_prefix_tokens > 0,
            extra_tokens=self.num_main_prefix_tokens,
        )
        self.pos_embed.data.copy_(
            torch.from_numpy(pos_embed).float().unsqueeze(0)
        )
        nn.init.normal_(self.register_tokens, std=0.02)

        w = self.x_embedder.proj.weight.data
        nn.init.xavier_uniform_(w.view([w.shape[0], -1]))
        nn.init.constant_(self.x_embedder.proj.bias, 0)
        nn.init.normal_(self.y_embedder.embedding_table.weight, std=0.02)
        nn.init.normal_(self.t_embedder.mlp[0].weight, std=0.02)
        nn.init.normal_(self.t_embedder.mlp[2].weight, std=0.02)

        # adaLN-Zero for both streams: the new architecture starts as an
        # identity residual stack, matching the stabilization of the baseline.
        for block in self.blocks:
            nn.init.constant_(block.patch_adaLN[-1].weight, 0)
            nn.init.constant_(block.patch_adaLN[-1].bias, 0)
            nn.init.constant_(block.register_adaLN[-1].weight, 0)
            nn.init.constant_(block.register_adaLN[-1].bias, 0)

        nn.init.constant_(self.final_layer.adaLN_modulation[-1].weight, 0)
        nn.init.constant_(self.final_layer.adaLN_modulation[-1].bias, 0)
        nn.init.constant_(self.final_layer.linear.weight, 0)
        nn.init.constant_(self.final_layer.linear.bias, 0)
        if self.final_layer.linear_cls is not None:
            nn.init.constant_(self.final_layer.linear_cls.weight, 0)
            nn.init.constant_(self.final_layer.linear_cls.bias, 0)

    def unpatchify(self, x, patch_size=None):
        c = self.out_channels
        p = self.x_embedder.patch_size[0] if patch_size is None else patch_size
        h = w = int(x.shape[1] ** 0.5)
        assert h * w == x.shape[1]
        x = x.reshape(shape=(x.shape[0], h, w, p, p, c))
        x = torch.einsum("nhwpqc->nchpwq", x)
        return x.reshape(shape=(x.shape[0], c, h * p, w * p))

    def _router_outputs(self, t, batch, dtype, device):
        if self.register_router is None:
            gates = torch.ones(
                batch,
                self.depth,
                self.num_register_tokens,
                dtype=dtype,
                device=device,
            )
            aux = {
                "budget_loss": gates.float().mean() * 0.0,
                "router_entropy": gates.float().mean() * 0.0,
                "mean_usage": torch.ones((), device=device),
                "expected_active_layers": torch.tensor(
                    float(self.depth), device=device
                ),
                "expected_active_registers": torch.tensor(
                    float(self.num_register_tokens), device=device
                ),
                "usage_by_layer": torch.ones(self.depth, device=device),
                "usage_by_register": torch.ones(
                    self.num_register_tokens, device=device
                ),
                "layer_logits": None,
                "soft_layer_gates": torch.ones(self.depth, device=device),
                "soft_gates": gates,
                "hard_mask": torch.ones_like(gates, dtype=torch.bool),
            }
            return gates, gates, aux
        return self.register_router(
            t=t, batch_size=batch, dtype=dtype, device=device
        )

    def forward(
        self,
        x,
        t,
        y,
        return_logvar=False,
        cls_token=None,
        return_attention=False,
        attention_layers=None,
        return_router_aux=False,
        semantic_target=None,
        return_cls_patch_semantic_kl=False,
        semantic_kl_only=False,
    ):
        patch_tokens = self.x_embedder(x)
        batch = patch_tokens.shape[0]
        t_embed = self.t_embedder(t)
        y_embed = self.y_embedder(y, self.training)
        c = t_embed + y_embed

        patch_tokens = patch_tokens + self.pos_embed[:, self.num_main_prefix_tokens :]
        if self.use_reg:
            if cls_token is None:
                raise ValueError("REG requires cls_token input")
            cls_token = self.wg_norm(self.cls_projectors2(cls_token))
            cls_token = cls_token.unsqueeze(1) + self.pos_embed[:, :1]
            main_tokens = torch.cat([cls_token, patch_tokens], dim=1)
        else:
            if cls_token is not None:
                raise ValueError(
                    "cls_token supplied although this model has use_reg=False"
                )
            main_tokens = patch_tokens

        register_tokens = self.register_tokens.expand(batch, -1, -1)
        gates, soft_gates, router_aux = self._router_outputs(
            t,
            batch,
            main_tokens.dtype,
            main_tokens.device,
        )

        if attention_layers is None:
            attention_layers = {len(self.blocks) - 1}
        else:
            attention_layers = {
                i if i >= 0 else len(self.blocks) + i for i in attention_layers
            }
        attentions = {}
        token_norms_by_layer = {}
        cls_patch_semantic_kl_by_layer = []
        zs = None
        D = main_tokens.shape[-1]

        for i, block in enumerate(self.blocks):
            collect_attention = return_attention and i in attention_layers
            main_tokens, register_tokens, attention, cls_patch_semantic_kl = block(
                main_tokens,
                register_tokens,
                c,
                register_gate=gates[:, i],
                register_soft_gate=soft_gates[:, i],
                semantic_target=semantic_target,
                use_cls_token=self.use_reg,
                return_attention=collect_attention,
                return_cls_patch_semantic_kl=return_cls_patch_semantic_kl,
            )
            if return_cls_patch_semantic_kl:
                cls_patch_semantic_kl_by_layer.append(cls_patch_semantic_kl)
            if attention is not None:
                attentions[i] = attention
                projected_registers = block.register_to_attention(
                    block.register_norm1(register_tokens)
                )
                insert_at = int(self.use_reg)
                full_for_norm = torch.cat(
                    [
                        main_tokens[:, :insert_at],
                        projected_registers,
                        main_tokens[:, insert_at:],
                    ],
                    dim=1,
                )
                token_norms_by_layer[i] = full_for_norm.norm(dim=-1)

            if self.use_repa and (not semantic_kl_only) and (i + 1) == self.encoder_depth:
                rep_tokens = main_tokens
                rep_length = rep_tokens.shape[1]
                zs = [
                    projector(rep_tokens.reshape(-1, D)).reshape(
                        batch, rep_length, -1
                    )
                    for projector in self.projectors
                ]

        router_aux["cls_patch_semantic_kl_by_layer"] = (
            torch.stack(cls_patch_semantic_kl_by_layer, dim=1)
            if return_cls_patch_semantic_kl
            else None
        )

        if semantic_kl_only:
            if not return_router_aux:
                raise ValueError("semantic_kl_only requires return_router_aux=True")
            return router_aux

        main_tokens, cls_output = self.final_layer(
            main_tokens,
            c,
            num_prefix_tokens=int(self.use_reg),
            use_reg=self.use_reg,
        )
        image_output = self.unpatchify(main_tokens)

        if return_attention:
            insert_at = int(self.use_reg)
            register_range = (
                insert_at,
                insert_at + self.num_register_tokens,
            )
            attention_info = {
                "weights": attentions,
                "class_index": 0 if self.use_reg else None,
                "patch_start": insert_at + self.num_register_tokens,
                "register_range": register_range,
                "num_register_tokens": self.num_register_tokens,
                "register_dim": self.register_dim,
                "dual_norm_type": self.dual_norm_type,
                "token_norms_by_layer": token_norms_by_layer,
                "router_soft_gates": router_aux["soft_gates"].detach(),
                "router_attention_gates": soft_gates.detach(),
                "router_hard_mask": router_aux["hard_mask"].detach(),
                "router_layer_gates": router_aux["soft_layer_gates"].detach(),
                "router_layer_logits": (
                    None
                    if router_aux["layer_logits"] is None
                    else router_aux["layer_logits"].detach()
                ),
            }
            if return_router_aux:
                return image_output, zs, cls_output, attention_info, router_aux
            return image_output, zs, cls_output, attention_info

        if return_router_aux:
            return image_output, zs, cls_output, router_aux
        return image_output, zs, cls_output


#################################################################################
#                   Sine/Cosine Positional Embedding Functions                  #
#################################################################################


def get_2d_sincos_pos_embed(embed_dim, grid_size, cls_token=False, extra_tokens=0):
    grid_h = np.arange(grid_size, dtype=np.float32)
    grid_w = np.arange(grid_size, dtype=np.float32)
    grid = np.meshgrid(grid_w, grid_h)
    grid = np.stack(grid, axis=0).reshape([2, 1, grid_size, grid_size])
    pos_embed = get_2d_sincos_pos_embed_from_grid(embed_dim, grid)
    if cls_token and extra_tokens > 0:
        pos_embed = np.concatenate(
            [np.zeros([extra_tokens, embed_dim]), pos_embed], axis=0
        )
    return pos_embed


def get_2d_sincos_pos_embed_from_grid(embed_dim, grid):
    assert embed_dim % 2 == 0
    emb_h = get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[0])
    emb_w = get_1d_sincos_pos_embed_from_grid(embed_dim // 2, grid[1])
    return np.concatenate([emb_h, emb_w], axis=1)


def get_1d_sincos_pos_embed_from_grid(embed_dim, pos):
    assert embed_dim % 2 == 0
    omega = np.arange(embed_dim // 2, dtype=np.float64)
    omega /= embed_dim / 2.0
    omega = 1.0 / 10000**omega
    pos = pos.reshape(-1)
    out = np.einsum("m,d->md", pos, omega)
    return np.concatenate([np.sin(out), np.cos(out)], axis=1)


#################################################################################
#                                   SiT Configs                                  #
#################################################################################


def SiT_XL_2(**kwargs):
    return SiT(
        depth=28,
        hidden_size=1152,
        decoder_hidden_size=1152,
        patch_size=2,
        num_heads=16,
        **kwargs,
    )


def SiT_XL_4(**kwargs):
    return SiT(
        depth=28,
        hidden_size=1152,
        decoder_hidden_size=1152,
        patch_size=4,
        num_heads=16,
        **kwargs,
    )


def SiT_XL_8(**kwargs):
    return SiT(
        depth=28,
        hidden_size=1152,
        decoder_hidden_size=1152,
        patch_size=8,
        num_heads=16,
        **kwargs,
    )


def SiT_L_2(**kwargs):
    return SiT(
        depth=24,
        hidden_size=1024,
        decoder_hidden_size=1024,
        patch_size=2,
        num_heads=16,
        **kwargs,
    )


def SiT_L_4(**kwargs):
    return SiT(
        depth=24,
        hidden_size=1024,
        decoder_hidden_size=1024,
        patch_size=4,
        num_heads=16,
        **kwargs,
    )


def SiT_L_8(**kwargs):
    return SiT(
        depth=24,
        hidden_size=1024,
        decoder_hidden_size=1024,
        patch_size=8,
        num_heads=16,
        **kwargs,
    )


def SiT_B_2(**kwargs):
    return SiT(
        depth=12,
        hidden_size=768,
        decoder_hidden_size=768,
        patch_size=2,
        num_heads=12,
        **kwargs,
    )


def SiT_B_4(**kwargs):
    return SiT(
        depth=12,
        hidden_size=768,
        decoder_hidden_size=768,
        patch_size=4,
        num_heads=12,
        **kwargs,
    )


def SiT_B_8(**kwargs):
    return SiT(
        depth=12,
        hidden_size=768,
        decoder_hidden_size=768,
        patch_size=8,
        num_heads=12,
        **kwargs,
    )


def SiT_S_2(**kwargs):
    return SiT(
        depth=12,
        hidden_size=384,
        decoder_hidden_size=384,
        patch_size=2,
        num_heads=6,
        **kwargs,
    )


def SiT_S_4(**kwargs):
    return SiT(
        depth=12,
        hidden_size=384,
        decoder_hidden_size=384,
        patch_size=4,
        num_heads=6,
        **kwargs,
    )


def SiT_S_8(**kwargs):
    return SiT(
        depth=12,
        hidden_size=384,
        decoder_hidden_size=384,
        patch_size=8,
        num_heads=6,
        **kwargs,
    )


SiT_models = {
    "SiT-XL/2": SiT_XL_2,
    "SiT-XL/4": SiT_XL_4,
    "SiT-XL/8": SiT_XL_8,
    "SiT-L/2": SiT_L_2,
    "SiT-L/4": SiT_L_4,
    "SiT-L/8": SiT_L_8,
    "SiT-B/2": SiT_B_2,
    "SiT-B/4": SiT_B_4,
    "SiT-B/8": SiT_B_8,
    "SiT-S/2": SiT_S_2,
    "SiT-S/4": SiT_S_4,
    "SiT-S/8": SiT_S_8,
}
