"""Attention diagnostics for shared-register dual-stream SiT checkpoints.

The primary visualization is CLS-query -> image-patch-key attention. For every
selected Transformer layer, the CLS attention row is averaged over heads,
reshaped to the spatial patch grid, and saved both as a raw heatmap and as an
overlay on the input image. Patch->CLS / patch->register statistics are retained
as secondary diagnostics, together with the learned router gates.
"""

import argparse
import csv
import os

import numpy as np
import torch
from timm.data import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from torchvision.transforms import Normalize

from dataset import CustomDataset
from models.sit import SiT_models
from loss import build_dino_semantic_target
from utils import load_encoders


def preprocess_dinov2(x, resolution):
    x = x / 255.0
    x = Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)(x)
    return torch.nn.functional.interpolate(
        x, 224 * (resolution // 256), mode="bicubic", align_corners=False
    )


def sample_posterior(moments, scale, bias):
    mean, std = torch.chunk(moments, 2, dim=1)
    return (mean + std * torch.randn_like(mean)) * scale + bias


def checkpoint_args(checkpoint):
    saved = checkpoint.get("args")
    if saved is None:
        return {}
    return saved if isinstance(saved, dict) else vars(saved)


def infer_encoder_dim(state, saved):
    if "encoder_embed_dim" in saved:
        return int(saved["encoder_embed_dim"])
    if "cls_projectors2.weight" in state:
        return int(state["cls_projectors2.weight"].shape[1])
    return 768


def build_model(checkpoint, state, device, fused_attn=False):
    saved = checkpoint_args(checkpoint)
    model_name = saved.get("model", "SiT-XL/2")
    resolution = int(saved.get("resolution", 256))
    encoder_dim = infer_encoder_dim(state, saved)
    model = SiT_models[model_name](
        input_size=resolution // 8,
        num_classes=int(saved.get("num_classes", 1000)),
        class_dropout_prob=float(saved.get("cfg_prob", 0.1)),
        z_dims=[encoder_dim],
        encoder_depth=int(saved.get("encoder_depth", 8)),
        use_reg=True,
        use_repa=True,
        num_register_tokens=int(saved.get("num_register_tokens", 4)),
        register_dim=int(saved.get("register_dim", 0)),
        register_mlp_ratio=float(saved.get("register_mlp_ratio", 4.0)),
        dual_norm_type=saved.get("dual_norm_type", "rmsnorm"),
        learnable_register_routing=bool(saved.get("learnable_register_routing", False)),
        router_temperature=float(saved.get("router_temperature", 0.10)),
        router_hard=bool(saved.get("router_hard", False)),
        router_hard_threshold=float(saved.get("router_hard_threshold", 0.5)),
        router_init_gate=float(saved.get("router_init_gate", 0.95)),
        router_budget_type=saved.get("router_budget_type", "target"),
        router_budget_target=float(saved.get("router_budget_target", 0.5)),
        fused_attn=fused_attn,
        qk_norm=bool(saved.get("qk_norm", False)),
    )
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        raise RuntimeError(f"Checkpoint mismatch: missing={missing}, unexpected={unexpected}")
    return model.to(device).eval(), saved, resolution, encoder_dim


def main(args):
    import matplotlib.pyplot as plt

    device = torch.device(args.device)
    checkpoint = torch.load(args.ckpt, map_location="cpu")
    state = checkpoint.get(args.checkpoint_key, checkpoint)
    model, saved, resolution, encoder_dim = build_model(
        checkpoint, state, device, fused_attn=False
    )

    encoders, _, _ = load_encoders(
        saved.get("enc_type", "dinov2-vit-b"),
        device,
        resolution,
        encoder_path=args.encoder_path or saved.get("encoder_path"),
    )
    encoder = encoders[0].eval()
    dataset = CustomDataset(args.data_dir, args.images_subdir, args.latents_subdir)
    raw_image, moments, label = dataset[args.index]
    raw_image = raw_image.unsqueeze(0).to(device)
    moments = moments.unsqueeze(0)
    if moments.ndim == 5 and moments.shape[1] == 1:
        moments = moments.squeeze(1)
    moments = moments.to(device)
    label = torch.as_tensor([int(label)], device=device)

    scale = torch.full((1, 4, 1, 1), 0.18215, device=device)
    clean_latent = sample_posterior(moments, scale, torch.zeros_like(scale))
    with torch.no_grad():
        z = encoder.forward_features(preprocess_dinov2(raw_image, resolution))
        clean_cls = z["x_norm_clstoken"]
        clean_patches = z["x_norm_patchtokens"]
        semantic_temperature = (
            args.semantic_kl_temperature
            if args.semantic_kl_temperature is not None
            else float(saved.get("semantic_kl_temperature", 0.10))
        )
        dino_semantic_target = build_dino_semantic_target(
            clean_cls,
            clean_patches,
            target_num_patches=model.x_embedder.num_patches,
            temperature=semantic_temperature,
        )[0].cpu().numpy().astype(np.float32)

    torch.manual_seed(args.seed)
    t = torch.tensor([args.timestep], device=device, dtype=clean_latent.dtype)
    noisy_latent = (1 - args.timestep) * clean_latent + args.timestep * torch.randn_like(clean_latent)
    noisy_cls = (1 - args.timestep) * clean_cls + args.timestep * torch.randn_like(clean_cls)
    # Always capture every Transformer layer so that we can compute a true
    # all-layer CLS->patch average. --layers only controls which individual
    # layer heatmaps/overlays are written to disk.
    plot_layers = set(args.layers if args.layers else list(range(model.depth)))
    capture_layers = list(range(model.depth))

    with torch.no_grad():
        result = model(
            noisy_latent,
            t,
            label,
            cls_token=noisy_cls,
            return_attention=True,
            attention_layers=capture_layers,
        )
    info = result[-1]
    rs, re = info["register_range"]
    patch_start = info["patch_start"]
    rows = []
    register_matrix = []
    patch_to_cls_by_layer = []
    patch_to_cls_spatial = {}
    cls_to_patch_spatial = {}
    cls_to_patch_total_by_layer = []
    used_layers = []
    for layer in sorted(info["weights"]):
        w = info["weights"][layer].float()  # [1,H,T,T]
        patch_q = w[:, :, patch_start:, :]
        per_reg = patch_q[:, :, :, rs:re].mean(dim=(0, 1, 2)).cpu().numpy()
        patch_to_reg = float(per_reg.sum())

        # IMPORTANT: attention is indexed as [query, key].  Therefore
        #   patch_q[..., 0] = patch-query -> CLS-key attention.
        # Keep both the layer average and the per-patch spatial map.
        patch_to_cls_per_patch = patch_q[:, :, :, 0].mean(dim=(0, 1))
        patch_to_cls = float(patch_to_cls_per_patch.mean())

        # The opposite direction, CLS-query -> patch-key, is retained as a
        # separate diagnostic so the two directions cannot be confused.
        cls_to_patch_per_patch = w[:, :, 0, patch_start:].mean(dim=(0, 1))
        cls_to_patch = float(cls_to_patch_per_patch.sum())
        cls_to_patch_total_by_layer.append(cls_to_patch)
        pred_spatial = cls_to_patch_per_patch.cpu().numpy().astype(np.float32)
        pred_spatial = pred_spatial / max(float(pred_spatial.sum()), 1e-12)
        target_safe = np.clip(dino_semantic_target, 1e-12, None)
        pred_safe = np.clip(pred_spatial, 1e-12, None)
        semantic_kl = float(np.sum(target_safe * (np.log(target_safe) - np.log(pred_safe))))
        row = {
            "layer": layer,
            "patch_to_cls": patch_to_cls,
            "patch_to_register_total": patch_to_reg,
            "cls_to_patch_total": cls_to_patch,
            "dino_semantic_kl": semantic_kl,
        }
        for k, value in enumerate(per_reg):
            row[f"patch_to_register_{k+1}"] = float(value)
        rows.append(row)
        register_matrix.append(per_reg)
        patch_to_cls_by_layer.append(patch_to_cls)
        patch_to_cls_spatial[layer] = patch_to_cls_per_patch.cpu().numpy()
        cls_to_patch_spatial[layer] = cls_to_patch_per_patch.cpu().numpy()
        used_layers.append(layer)

    os.makedirs(args.output_dir, exist_ok=True)
    csv_path = os.path.join(args.output_dir, "attention_summary.csv")
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    # ------------------------------------------------------------------
    # PRIMARY VISUALIZATION: CLS-query -> patch-key attention.
    # Attention is indexed as [query, key], therefore
    #     w[:, :, 0, patch_start:]
    # is exactly the attention distribution used by CLS to read image patches.
    # ------------------------------------------------------------------

    # Prepare the original image for overlays. CustomDataset images in this
    # project are normally stored in [0, 255], but keep this robust to [0, 1]
    # and [-1, 1] inputs.
    display_image = raw_image[0].detach().float().cpu()
    if display_image.ndim != 3:
        raise RuntimeError(f"Expected CHW image tensor, got {tuple(display_image.shape)}")
    if display_image.shape[0] > 3:
        display_image = display_image[:3]
    if float(display_image.min()) < 0:
        display_image = (display_image + 1.0) / 2.0
    elif float(display_image.max()) > 1.5:
        display_image = display_image / 255.0
    display_image = display_image.clamp(0, 1).permute(1, 2, 0).numpy()

    # Clean DINO semantic target used by the training KL objective.
    target_n = int(dino_semantic_target.shape[0])
    target_grid = int(round(target_n ** 0.5))
    if target_grid * target_grid == target_n:
        target_spatial = dino_semantic_target.reshape(target_grid, target_grid)
        np.save(os.path.join(args.output_dir, "dino_semantic_target.npy"), target_spatial)

        plt.figure(figsize=(5.5, 5))
        im = plt.imshow(target_spatial, interpolation="nearest")
        plt.xlabel("Patch x")
        plt.ylabel("Patch y")
        plt.title(f"DINO semantic target, tau={semantic_temperature:.3f}")
        plt.colorbar(im, label="target probability")
        plt.tight_layout()
        plt.savefig(os.path.join(args.output_dir, "dino_semantic_target.png"), dpi=220)
        plt.close()

        target_heat = torch.from_numpy(target_spatial)[None, None]
        target_heat = torch.nn.functional.interpolate(
            target_heat,
            size=display_image.shape[:2],
            mode="bilinear",
            align_corners=False,
        )[0, 0].numpy()
        th_min, th_max = float(target_heat.min()), float(target_heat.max())
        target_vis = (target_heat - th_min) / max(th_max - th_min, 1e-12)
        plt.figure(figsize=(6, 6))
        plt.imshow(display_image)
        overlay = plt.imshow(
            target_vis,
            interpolation="bilinear",
            alpha=args.overlay_alpha,
            cmap=args.colormap,
            vmin=0.0,
            vmax=1.0,
        )
        plt.axis("off")
        plt.title(f"DINO semantic target overlay, tau={semantic_temperature:.3f}")
        plt.colorbar(overlay, fraction=0.046, pad=0.04, label="relative target")
        plt.tight_layout()
        plt.savefig(
            os.path.join(args.output_dir, "dino_semantic_target_overlay.png"),
            dpi=220,
            bbox_inches="tight",
        )
        plt.close()

    # Layer-wise total mass that CLS allocates to all image patches.
    plt.figure(figsize=(7, 4.5))
    plt.plot(used_layers, cls_to_patch_total_by_layer, marker="o")
    plt.xlabel("Transformer layer")
    plt.ylabel("Total attention mass")
    plt.title(f"CLS -> patch attention mass, t={args.timestep:.2f}")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, "cls_to_patch_total_by_layer.png"), dpi=200)
    plt.close()

    np.save(
        os.path.join(args.output_dir, "cls_to_patch_total_by_layer.npy"),
        np.asarray(cls_to_patch_total_by_layer, dtype=np.float32),
    )

    # Spatial heatmap for every requested layer. The .npy file always stores
    # the RAW attention probabilities. PNG heatmaps show the same values; the
    # overlay uses max-normalization only for visibility on top of the image.
    for layer, values in cls_to_patch_spatial.items():
        # --layers controls only the individual per-layer visualizations.
        # Every layer has already been captured above for the all-layer mean.
        if layer not in plot_layers:
            continue

        n_patches = int(values.shape[0])
        grid = int(round(n_patches ** 0.5))
        if grid * grid != n_patches:
            print(
                f"warning: layer {layer} has {n_patches} patch keys, which is not "
                "a square grid; skipping CLS->patch spatial heatmap"
            )
            continue

        spatial = values.reshape(grid, grid).astype(np.float32)
        np.save(
            os.path.join(args.output_dir, f"cls_to_patch_layer_{layer:02d}.npy"),
            spatial,
        )

        # Raw CLS -> patch attention heatmap.
        plt.figure(figsize=(5.5, 5))
        im = plt.imshow(spatial, interpolation="nearest")
        plt.xlabel("Patch x")
        plt.ylabel("Patch y")
        plt.title(f"CLS -> patch attention, layer={layer}, t={args.timestep:.2f}")
        plt.colorbar(im, label="attention from CLS query")
        plt.tight_layout()
        plt.savefig(
            os.path.join(args.output_dir, f"cls_to_patch_layer_{layer:02d}.png"),
            dpi=200,
        )
        plt.close()

        # Upsample the patch-grid attention to image resolution and overlay it
        # on the input image. Normalization here is visualization-only.
        heat = torch.from_numpy(spatial)[None, None]
        heat = torch.nn.functional.interpolate(
            heat,
            size=display_image.shape[:2],
            mode="bilinear",
            align_corners=False,
        )[0, 0].numpy()
        heat_min, heat_max = float(heat.min()), float(heat.max())
        if heat_max > heat_min:
            heat_vis = (heat - heat_min) / (heat_max - heat_min)
        else:
            heat_vis = np.zeros_like(heat)

        plt.figure(figsize=(6, 6))
        plt.imshow(display_image)
        overlay = plt.imshow(
            heat_vis,
            interpolation="bilinear",
            alpha=args.overlay_alpha,
            cmap=args.colormap,
            vmin=0.0,
            vmax=1.0,
        )
        plt.axis("off")
        plt.title(f"CLS -> image attention, layer={layer}, t={args.timestep:.2f}")
        plt.colorbar(overlay, fraction=0.046, pad=0.04, label="relative CLS attention")
        plt.tight_layout()
        plt.savefig(
            os.path.join(args.output_dir, f"cls_to_patch_overlay_layer_{layer:02d}.png"),
            dpi=220,
            bbox_inches="tight",
        )
        plt.close()

    # ------------------------------------------------------------------
    # ALL-LAYER MEAN CLS -> PATCH ATTENTION.
    #
    # raw_mean: arithmetic mean of the raw attention probabilities over all
    # Transformer layers. This preserves how much total attention mass each
    # layer allocates to image patches.
    #
    # spatial_mean: first renormalize the CLS->patch row inside every layer to
    # sum to one over image patches, then average over layers. This answers the
    # complementary question "which image regions does CLS prefer on average?"
    # without letting layers with larger total patch-attention mass dominate.
    # ------------------------------------------------------------------
    all_layer_values = np.stack(
        [cls_to_patch_spatial[layer] for layer in sorted(cls_to_patch_spatial)],
        axis=0,
    ).astype(np.float32)
    n_patches = int(all_layer_values.shape[-1])
    grid = int(round(n_patches ** 0.5))
    if grid * grid == n_patches:
        raw_mean = all_layer_values.mean(axis=0).reshape(grid, grid)
        denom = np.clip(all_layer_values.sum(axis=1, keepdims=True), 1e-12, None)
        spatial_mean = (all_layer_values / denom).mean(axis=0).reshape(grid, grid)

        np.save(os.path.join(args.output_dir, "cls_to_patch_all_layers_mean.npy"), raw_mean)
        np.save(
            os.path.join(args.output_dir, "cls_to_patch_all_layers_spatial_mean.npy"),
            spatial_mean,
        )

        def save_mean_heatmap(spatial, stem, title, colorbar_label):
            plt.figure(figsize=(5.5, 5))
            im = plt.imshow(spatial, interpolation="nearest")
            plt.xlabel("Patch x")
            plt.ylabel("Patch y")
            plt.title(title)
            plt.colorbar(im, label=colorbar_label)
            plt.tight_layout()
            plt.savefig(os.path.join(args.output_dir, stem + ".png"), dpi=220)
            plt.close()

            heat = torch.from_numpy(spatial)[None, None]
            heat = torch.nn.functional.interpolate(
                heat,
                size=display_image.shape[:2],
                mode="bilinear",
                align_corners=False,
            )[0, 0].numpy()
            heat_min, heat_max = float(heat.min()), float(heat.max())
            if heat_max > heat_min:
                heat_vis = (heat - heat_min) / (heat_max - heat_min)
            else:
                heat_vis = np.zeros_like(heat)

            plt.figure(figsize=(6, 6))
            plt.imshow(display_image)
            overlay = plt.imshow(
                heat_vis,
                interpolation="bilinear",
                alpha=args.overlay_alpha,
                cmap=args.colormap,
                vmin=0.0,
                vmax=1.0,
            )
            plt.axis("off")
            plt.title(title.replace("attention", "image attention"))
            plt.colorbar(
                overlay,
                fraction=0.046,
                pad=0.04,
                label="relative CLS attention",
            )
            plt.tight_layout()
            plt.savefig(
                os.path.join(args.output_dir, stem.replace("cls_to_patch", "cls_to_patch_overlay") + ".png"),
                dpi=220,
                bbox_inches="tight",
            )
            plt.close()

        save_mean_heatmap(
            raw_mean,
            "cls_to_patch_all_layers_mean",
            f"CLS -> patch attention, all-layer mean, t={args.timestep:.2f}",
            "mean raw attention from CLS query",
        )
        save_mean_heatmap(
            spatial_mean,
            "cls_to_patch_all_layers_spatial_mean",
            f"CLS -> patch spatial preference, all-layer mean, t={args.timestep:.2f}",
            "mean normalized spatial attention",
        )
    else:
        print(
            f"warning: {n_patches} patch keys do not form a square grid; "
            "skipping all-layer CLS->patch spatial mean"
        )

    # ------------------------------------------------------------------
    # SECONDARY DIAGNOSTIC: patch-query -> CLS-key attention.
    # This is useful for the attention-sink hypothesis, but it is NOT the
    # spatial semantic-attention visualization requested above.
    # ------------------------------------------------------------------
    plt.figure(figsize=(7, 4.5))
    plt.plot(used_layers, patch_to_cls_by_layer, marker="o")
    plt.xlabel("Transformer layer")
    plt.ylabel("Mean attention mass")
    plt.title(f"Patch -> CLS attention, t={args.timestep:.2f}")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, "patch_to_cls_by_layer.png"), dpi=200)
    plt.close()

    np.save(
        os.path.join(args.output_dir, "patch_to_cls_by_layer.npy"),
        np.asarray(patch_to_cls_by_layer, dtype=np.float32),
    )

    # 3) Patch-query -> register-key attention.
    mat = np.asarray(register_matrix)
    plt.figure(figsize=(max(5, model.num_register_tokens), max(5, len(used_layers) * 0.25)))
    im = plt.imshow(mat, aspect="auto", origin="lower")
    plt.xticks(range(model.num_register_tokens), [f"R{k+1}" for k in range(model.num_register_tokens)])
    plt.yticks(range(len(used_layers)), used_layers)
    plt.xlabel("Register")
    plt.ylabel("Layer")
    plt.title(f"Patch -> register attention, t={args.timestep:.2f}")
    plt.colorbar(im, label="mean attention mass")
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, "patch_to_register.png"), dpi=200)
    plt.close()

    layer_gates = info["router_layer_gates"].float().cpu().numpy()
    np.save(os.path.join(args.output_dir, "router_layer_gates.npy"), layer_gates)
    plt.figure(figsize=(7, 4))
    plt.plot(np.arange(model.depth), layer_gates, marker="o", linewidth=1.5)
    plt.ylim(0, 1)
    plt.xlabel("Layer")
    plt.ylabel("Register activation weight")
    plt.title("Learned layer-only register routing")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(os.path.join(args.output_dir, "router_layer_gates.png"), dpi=200)
    plt.close()
    print(f"saved {csv_path} and plots to {args.output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--checkpoint-key", choices=["ema", "model"], default="ema")
    parser.add_argument("--data-dir", required=True)
    parser.add_argument("--images-subdir", default="imagenet_256_vae")
    parser.add_argument("--latents-subdir", default="vae-sd")
    parser.add_argument("--encoder-path", default=None)
    parser.add_argument("--index", type=int, default=0)
    parser.add_argument("--timestep", type=float, default=0.8)
    parser.add_argument("--layers", nargs="*", type=int, default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--output-dir", default="attention_diagnostics")
    parser.add_argument(
        "--semantic-kl-temperature",
        type=float,
        default=None,
        help=(
            "DINO semantic-target temperature. Defaults to the checkpoint value "
            "or 0.10 for older checkpoints."
        ),
    )
    parser.add_argument(
        "--overlay-alpha",
        type=float,
        default=0.45,
        help="Opacity of the CLS->patch heatmap when overlaid on the input image.",
    )
    parser.add_argument(
        "--colormap",
        default="jet",
        help="Matplotlib colormap used for the CLS->patch overlay.",
    )
    main(parser.parse_args())
