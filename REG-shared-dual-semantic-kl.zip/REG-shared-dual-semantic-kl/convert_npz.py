import os
import glob
import numpy as np
from PIL import Image
from tqdm import tqdm

def pack_images_to_npz(img_dir, output_npz_path, num_samples=50000, image_size=256):
    # 支持 png 和 jpg
    img_paths = sorted(glob.glob(os.path.join(img_dir, "**", "*.png"), recursive=True))
    if len(img_paths) < num_samples:
        img_paths += sorted(glob.glob(os.path.join(img_dir, "**", "*.jpg"), recursive=True))
    
    img_paths = img_paths[:num_samples]
    assert len(img_paths) == num_samples, f"图片数量不足 {num_samples} 张，当前只有 {len(img_paths)} 张！"

    print(f"正在读取 {num_samples} 张图片...")
    # 预分配内存，类型严格要求为 uint8
    samples = np.empty((num_samples, image_size, image_size, 3), dtype=np.uint8)

    for i, path in enumerate(tqdm(img_paths)):
        with Image.open(path) as img:
            img = img.convert("RGB")
            if img.size != (image_size, image_size):
                img = img.resize((image_size, image_size), Image.BICUBIC)
            samples[i] = np.array(img, dtype=np.uint8)

    print(f"正在保存至 {output_npz_path} (可能需要 1~2 分钟)...")
    # 注意：ADM 评测工具默认读取字典中的 'arr_0'
    np.savez(output_npz_path, samples)
    print("打包完成！")

if __name__ == "__main__":
    IMAGE_FOLDER = "/nas025/shie.lzw/REG-register-FGH-dynamic/REG-register/samples_h_xl_shared4_dynamic8/SiT-XL-2-0400000-size-256-vae-mse-cfg-1.0-seed-0-sde-0.85-1.0"  # 你的50K图片文件夹路径
    OUTPUT_FILE = "/nas025/shie.lzw/REG-register-FGH-dynamic/REG-register/samples_h_xl_shared4_dynamic8//samples_400K.npz"
    pack_images_to_npz(IMAGE_FOLDER, OUTPUT_FILE)
