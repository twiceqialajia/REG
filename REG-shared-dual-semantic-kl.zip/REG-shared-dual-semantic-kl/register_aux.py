"""Utilities for register-only auxiliary gradients."""

import torch


def is_register_aux_parameter(name):
    """Return True for parameters belonging to the specialized register path."""
    name = name.replace("module.", "")
    return (
        name == "register_tokens"
        or name.startswith("register_router.")
        or ".register_norm" in name
        or ".register_adaLN" in name
        or ".register_mlp" in name
        or ".register_to_attention" in name
        or ".attention_to_register" in name
    )


def get_register_aux_parameters(model, accelerator, scope="tokens_router"):
    """Return parameters allowed to receive semantic-KL auxiliary gradients.

    scopes:
      - tokens_router: shared register embeddings + optional layer router only.
        Lowest-memory choice for L/XL.
      - full: all register-specific Norm/AdaLN/MLP/projection parameters plus
        register embeddings/router. This is the strongest register-only
        supervision, but holds an auxiliary gradient tensor for each selected
        parameter until it is merged into the main gradient buffer.
    """
    if scope not in {"tokens_router", "full"}:
        raise ValueError("semantic KL grad scope must be 'tokens_router' or 'full'")
    unwrapped = accelerator.unwrap_model(model)
    out = []
    for name, param in unwrapped.named_parameters():
        if not param.requires_grad:
            continue
        clean = name.replace("module.", "")
        if scope == "tokens_router":
            keep = clean == "register_tokens" or clean.startswith("register_router.")
        else:
            keep = is_register_aux_parameter(clean)
        if keep:
            out.append((name, param))
    return out


def compute_register_only_aux_grads(loss, named_params, accelerator):
    """Differentiate a separate auxiliary forward only w.r.t. register params.

    Important: train.py invokes this after the normal main-loss backward, so the
    main computation graph has already been released. No retain_graph=True is
    needed here; this is the key memory difference from the old entropy path.
    """
    if not named_params:
        return []

    accumulation = float(getattr(accelerator, "gradient_accumulation_steps", 1))
    aux_loss = loss / accumulation
    params = [p for _, p in named_params]
    grads = torch.autograd.grad(
        aux_loss,
        params,
        retain_graph=False,
        allow_unused=True,
        create_graph=False,
    )

    reduced = []
    num_processes = int(getattr(accelerator, "num_processes", 1))
    for grad in grads:
        if grad is None:
            reduced.append(None)
            continue
        grad = grad.detach()
        if num_processes > 1:
            grad = accelerator.reduce(grad, reduction="mean")
        reduced.append(grad)
    return reduced


def add_register_aux_grads(named_params, aux_grads, accelerator):
    """Merge unscaled auxiliary gradients into Accelerate's main gradients."""
    if not aux_grads:
        return
    scaler = getattr(accelerator, "scaler", None)
    amp_scale = float(scaler.get_scale()) if scaler is not None else 1.0
    for (_, param), grad in zip(named_params, aux_grads):
        if grad is None:
            continue
        grad = grad.to(device=param.device, dtype=param.dtype) * amp_scale
        if param.grad is None:
            param.grad = grad.clone()
        else:
            param.grad.add_(grad)
